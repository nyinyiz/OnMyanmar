package com.example.user.onmyanmar.Model;

/**
 * Created by User on 7/27/2017.
 */

public class NewExpenseSyncModel {

    String user_id;
    String uuid;
    String expense_type_id;
    String amount;
    String on_credit;
    String descr;
    String note;
    String submitted_at;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getExpense_type_id() {
        return expense_type_id;
    }

    public void setExpense_type_id(String expense_type_id) {
        this.expense_type_id = expense_type_id;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getOn_credit() {
        return on_credit;
    }

    public void setOn_credit(String on_credit) {
        this.on_credit = on_credit;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getSubmitted_at() {
        return submitted_at;
    }

    public void setSubmitted_at(String submitted_at) {
        this.submitted_at = submitted_at;
    }
}
