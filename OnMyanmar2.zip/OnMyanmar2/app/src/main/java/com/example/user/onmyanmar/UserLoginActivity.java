package com.example.user.onmyanmar;


import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.util.Log;

import android.view.View;

import android.widget.Button;

import android.widget.EditText;

import android.widget.Toast;


import com.example.user.onmyanmar.Model.AllUserDataModel;

import com.example.user.onmyanmar.Model.AllUserMessageDataModel;
import com.example.user.onmyanmar.Model.AllequipmentsModel;
import com.example.user.onmyanmar.Model.IncomeModel;
import com.example.user.onmyanmar.Model.Income_ExpenseModel;
import com.example.user.onmyanmar.api.Application;
import com.example.user.onmyanmar.api.RetrofitHelper;


import org.json.JSONObject;


import me.drakeet.materialdialog.MaterialDialog;

import retrofit2.Call;

import retrofit2.Callback;

import retrofit2.Response;

import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_ADVANCED_RENT;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_ADVERTISING;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_BODY;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_DEL;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_DESCR;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_EMPLOYEE_ID;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_FIRST_NAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_INSTALLATION_FEES;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_LASTNAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_LICENSS;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_MESSAGE_ID;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_NAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_OPERATING_CASH;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_OTHER_FEES;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_QUANTITY;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEEN;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEND;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEND_BY;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_STARTING_INVENTROY;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_STARTUP_BUDGET_ID;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_START_DATE;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SUBJECT;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_TIMESTAMP;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_TRIGGER;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_UNIT_PRICE;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_USER_ID;
//import static com.facebook.internal.FacebookRequestErrorClassification.KEY_NAME;


public class UserLoginActivity extends AppCompatActivity {

    private ProgressDialog mProgressDialog;
    RetrofitHelper retrofitHelper;
    OnMyanmar_DataBase dataBase;
    ContentValues values_income_expense, values_expense, value_income;
    MaterialDialog mMaterialDialog;


    AllUserDataModel alluser;
    AllUserDataModel allUserDataModel;

    IncomeModel income_amount;
    Income_ExpenseModel allincome_expense;

    AllUserMessageDataModel allmessage;

    AllequipmentsModel allequipment;


    EditText name, password;

    Button login;


    PrefManager pref;

    JSONObject userdata = null;


    String username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        mProgressDialog = new ProgressDialog(UserLoginActivity.this);
        mProgressDialog.setIndeterminate(false);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        retrofitHelper = new RetrofitHelper();
        pref = new PrefManager(UserLoginActivity.this);
        dataBase = new OnMyanmar_DataBase(UserLoginActivity.this, pref.getDB_NAME());
        name = (EditText) findViewById(R.id.user_name);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.login);
        values_expense = new ContentValues();
        values_income_expense = new ContentValues();
        value_income = new ContentValues();
        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String user_name = name.getText().toString();
                String user_password = password.getText().toString();
                if (user_name.isEmpty() || user_password.isEmpty()) {
                    mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                            .setTitle("Error")
                            .setMessage("Please fill Email and Password!!!")
                            .setPositiveButton("OK", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mMaterialDialog.dismiss();

                                }
                            });
                    mMaterialDialog.show();
                } else
                {
                    mProgressDialog.show();
                    logingetall(user_name, user_password);
                }

            }

        });

    }

    public class ProgressTask extends AsyncTask<Fragment, Void, Fragment> {
        @Override
        protected Fragment doInBackground(Fragment... params) {
            return null;
        }

        @Override
        protected void onPreExecute() {
            mProgressDialog.show();
        }

        @Override
        protected void onPostExecute(Fragment result) {
            mProgressDialog.dismiss();
        }
    }

    public void logingetall(String email, String password) {
        Call<AllUserDataModel> call = retrofitHelper.login(email, password);
        call.enqueue(new Callback<AllUserDataModel>() {

            @Override
            public void onResponse(Call<AllUserDataModel> call, Response<AllUserDataModel> response) {
                if (response.isSuccessful()) {
                    allUserDataModel = response.body();
                    pref.createLoginSession(Integer.parseInt(allUserDataModel.getUser_data().getUser_id()), allUserDataModel.getUser_data().getUsername(),allUserDataModel.getUser_data().getUuid());
                    insert_user_data();
                    insert_sale_data();
                    insert_user_equipment();
//                    insert_startup_budget();
//                    getIncome(allUserDataModel.getUser_data().getUser_id());
//                    getExpense(allUserDataModel.getUser_data().getUser_id());
                    getIncome(pref.getID() + "");
                    getExpense(pref.getID() + "");
                    getIncomeExpense(allUserDataModel.getUser_data().getUser_id());
//                    insert_sale();
                    getMessage();
                    Log.d("****Pref", pref.getDB_NAME() + " AND " + pref.getID());
                    Intent intent = new Intent(UserLoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();

                } else {
                    Log.d("Fail", "parameter");
                    mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                            .setTitle("Fail")
                            .setMessage("Your email and password are incorrect!!!")
                            .setPositiveButton("OK", new View.OnClickListener() {

                                @Override
                                public void onClick(View v) {
                                    mMaterialDialog.dismiss();

                                }

                            });
                    mMaterialDialog.show();
                }

            }

            @Override
            public void onFailure(Call<AllUserDataModel> call, Throwable t) {
                Log.d("ONFail", t + "");
                mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                        .setTitle("Error")
                        .setMessage("Your email and password are incorrect!!!")
                        .setPositiveButton("OK", new View.OnClickListener() {

                            @Override
                            public void onClick(View v) {
                                mMaterialDialog.dismiss();

                            }

                        });
                mMaterialDialog.show();

            }

        });

    }

    public void insert_startup_budget() {
        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(UserLoginActivity.this, pref.getDB_NAME());
        ContentValues values = new ContentValues();
        values.put(KEY_STARTUP_BUDGET_ID, allUserDataModel.getStartup_budget().getId());
        values.put(KEY_USER_ID, allUserDataModel.getStartup_budget().getUser_id());
        values.put(KEY_INSTALLATION_FEES, allUserDataModel.getStartup_budget().getInstallation_fees());
        values.put(KEY_STARTING_INVENTROY, allUserDataModel.getStartup_budget().getStarting_inventory());
        values.put(KEY_OTHER_FEES, allUserDataModel.getStartup_budget().getOther_fees());
        values.put(KEY_ADVANCED_RENT, allUserDataModel.getStartup_budget().getAdvanced_rent());
        values.put(KEY_LICENSS, allUserDataModel.getStartup_budget().getLicense());
        values.put(KEY_ADVERTISING, allUserDataModel.getStartup_budget().getAdvertising());
        values.put(KEY_OPERATING_CASH, allUserDataModel.getStartup_budget().getOperating_cash());
        values.put(KEY_START_DATE, allUserDataModel.getStartup_budget().getStart_date());
        values.put(KEY_TIMESTAMP, allUserDataModel.getStartup_budget().getTimestamp());
        long a = dataBase.saved_startup_budget_retro(values);
        Log.d("***error save**", a + "");

    }

    public void insert_user_equipment() {
        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(UserLoginActivity.this, pref.getDB_NAME());
        ContentValues values = new ContentValues();
        for (int i = 0; i < allUserDataModel.getEquipments().size(); i++) {
            values.put(KEY_NAME, allUserDataModel.getEquipments().get(i).getName());
            values.put(KEY_UNIT_PRICE, "1");
            values.put(KEY_QUANTITY, "1");
            values.put(KEY_DESCR, "1");
            values.put(KEY_TIMESTAMP, "1");
            long a = dataBase.saved_equipment_retro(values);
            Log.d("***error save**", a + "");

        }

    }
    public void insert_sale_data()
    {
        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(UserLoginActivity.this, pref.getDB_NAME());
        ContentValues values = new ContentValues();
        for (int i = 0; i < allUserDataModel.getSales().size(); i++) {

            values.put(dataBase.KEY_PRODUCT_TYPE_ID, allUserDataModel.getSales().get(i).getId());
            values.put(KEY_NAME, allUserDataModel.getSales().get(i).getName());
            values.put(dataBase.KEY_TIMESTAMP, allUserDataModel.getSales().get(i).getTimestamp());
            values.put(dataBase.KEY_SYNC, 0 + "");

            Long a = dataBase.save_sale_data_retro(values);
            Log.d("Sale data", a + "");

        }

    }


    public void insert_user_data() {
        ContentValues values = new ContentValues();

        Application.USER_NAME = allUserDataModel.getUser_data().getFirstname()  +" "+
                        allUserDataModel.getUser_data().getMiddlename() + " "+
                        allUserDataModel.getUser_data().getLastname();

        values.put(dataBase.KEY_USER_NAME, allUserDataModel.getUser_data().getFirstname() + " "
                + allUserDataModel.getUser_data().getMiddlename() + " "
                + allUserDataModel.getUser_data().getLastname());
        values.put(dataBase.KEY_ROLE_ID, allUserDataModel.getUser_data().getRole_id());
        values.put(dataBase.KEY_PASSWORD, allUserDataModel.getUser_data().getPassword());
        values.put(dataBase.KEY_USER_ID, allUserDataModel.getUser_data().getUser_id());
        values.put(dataBase.KEY_UUID, allUserDataModel.getUser_data().getUuid());
        values.put(dataBase.KEY_TOWNSHIP, allUserDataModel.getUser_data().getTownship());
        values.put(dataBase.KEY_NRC_NO, allUserDataModel.getUser_data().getNrc_no());
        values.put(dataBase.KEY_PHONE, allUserDataModel.getUser_data().getPhone());
        values.put(dataBase.KEY_LOGED_IN, "1");
        long a = dataBase.save_user_data_retro(values);
        Log.d("***error save**", a + "");

    }

    public void getIncome(String user_id) {
        Call<IncomeModel> call = retrofitHelper.getIncome(user_id);
        call.enqueue(new Callback<IncomeModel>() {

            @Override
            public void onResponse(Call<IncomeModel> call, Response<IncomeModel> response) {
                if (response.isSuccessful()) {
                    income_amount = response.body();
                    ContentValues values = new ContentValues();
                    values.put(dataBase.KEY_SALE_AMOUNT, income_amount.getAmount());
                    values.put(dataBase.KEY_PRODUCT_TYPE_ID, "1");
                    values.put(dataBase.KEY_UNIT, "1");
                    values.put(dataBase.KEY_SEND, "1");
                    values.put(dataBase.KEY_INCOME_ID, "1");
                    dataBase.save_income(values);

                } else {
                    Log.d("Fail", "parameter");
                    mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                            .setTitle("Fail")
                            .setMessage("Your email and password are incorrect!!!")
                            .setPositiveButton("OK", new View.OnClickListener() {

                                @Override
                                public void onClick(View v) {
                                    mMaterialDialog.dismiss();

                                }

                            });
                    mMaterialDialog.show();

                }

            }


            @Override
            public void onFailure(Call<IncomeModel> call, Throwable t) {
                Log.d("ONFail", t + "");
                mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                        .setTitle("Error")
                        .setMessage("Your email and password are incorrect!!!")
                        .setPositiveButton("OK", new View.OnClickListener() {

                            @Override
                            public void onClick(View v) {
                                mMaterialDialog.dismiss();

                            }

                        });
                mMaterialDialog.show();

            }

        });

    }

    public void getExpense(String user_id) {
        Call<IncomeModel> call = retrofitHelper.getExpense(user_id);
        call.enqueue(new Callback<IncomeModel>() {

            @Override
            public void onResponse(Call<IncomeModel> call, Response<IncomeModel> response) {
                if (response.isSuccessful()) {
                    income_amount = response.body();
                    ContentValues values = new ContentValues();
                    values.put(dataBase.KEY_CATEGORY_ID, "1");
                    values.put(dataBase.KEY_AMOUNT, income_amount.getAmount());
                    values.put(dataBase.KEY_DESCRIPTION, "1");
                    values.put(dataBase.KEY_ON_CREDIT, "1");
                    values.put(dataBase.KEY_NOTE, "1");
                    values.put(dataBase.KEY_SAVE_DATE, "1");
                    dataBase.save_expense(values);

                } else {
                    Log.d("Fail", "parameter");
                    mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                            .setTitle("Fail")
                            .setMessage("Your email and password are incorrect!!!")
                            .setPositiveButton("OK", new View.OnClickListener() {

                                @Override
                                public void onClick(View v) {
                                    mMaterialDialog.dismiss();

                                }

                            });
                    mMaterialDialog.show();

                }

            }


            @Override
            public void onFailure(Call<IncomeModel> call, Throwable t) {
                Log.d("ONFail", t + "");
                mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                        .setTitle("Error")
                        .setMessage("Your email and password are incorrect!!!")
                        .setPositiveButton("OK", new View.OnClickListener() {

                            @Override
                            public void onClick(View v) {
                                mMaterialDialog.dismiss();

                            }

                        });
                mMaterialDialog.show();

            }

        });

    }

    public void getIncomeExpense(String user_id) {
        Call<Income_ExpenseModel> call = retrofitHelper.getIncomeExpense(user_id);
        call.enqueue(new Callback<Income_ExpenseModel>() {
            @Override
            public void onResponse(Call<Income_ExpenseModel> call, Response<Income_ExpenseModel> response) {
                if (response.isSuccessful()) {
                    allincome_expense = response.body();
                    if (allincome_expense.getQuery().isEmpty()) {
                        mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                                .setTitle("Sorry")
                                .setMessage("Book are not in this genre!!!")
                                .setPositiveButton("OK", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mMaterialDialog.dismiss();
                                    }
                                });
                        mMaterialDialog.show();
                    } else {
                        Long a;
                        Log.d("Size Income expense", allincome_expense.getQuery().size() + "");
                        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(UserLoginActivity.this, pref.getDB_NAME());
                        ContentValues values = new ContentValues();
                        for (int i = 0; i < allincome_expense.getQuery().size(); i++) {

                            if (allincome_expense.getQuery().get(i).getExpense()) {
                                values_expense.put(dataBase.KEY_SAVE_DATE, allincome_expense.getQuery().get(i).getTimestamp());
                                values_expense.put(dataBase.KEY_CATEGORY_ID, "");
                                values_expense.put(dataBase.KEY_AMOUNT, allincome_expense.getQuery().get(i).getProduct_price());
//                                values_expense.put(dataBase.KEY_UNIT, allincome_expense.getQuery().get(i).getQuantiy());
//                                values_expense.put(dataBase.KEY_PRICE_PER_ONE, allincome_expense.getQuery().get(i).getAmount());
//                                values_expense.put(dataBase.KEY_DESCRIPTION, "1");
                                values_expense.put(dataBase.KEY_ON_CREDIT, "0");
//                                values_expense.put(dataBase.KEY_NOTE, "1");
                                values_expense.put(dataBase.KEY_EDITED, "0");
                                values_expense.put(dataBase.KEY_UPDATED, "0");
                                values_expense.put(dataBase.KEY_SEND, "0");
                                values_expense.put(dataBase.KEY_UUID, pref.getID());
                                values_expense.put(dataBase.KEY_DELETED, "0");
                                values_expense.put(dataBase.KEY_SYNC, 0+"");
                                values_expense.put(dataBase.KEY_SUBMITTED_AT, allincome_expense.getQuery().get(i).getSubmitted_at());
                                dataBase.insert_expenese(values_expense);
                                Log.d("On UserLogin Eid", dataBase.get_expense_id().get(0));
                                values_income_expense.put(dataBase.KEY_INCOME, allincome_expense.getQuery().get(i).getIncome() + "");
                                values_income_expense.put(dataBase.KEY_EXPENSE, allincome_expense.getQuery().get(i).getExpense() + "");
                                values_income_expense.put(dataBase.KEY_PRODUCT_NAME, allincome_expense.getQuery().get(i).getProduct_name());
                                values_income_expense.put(dataBase.KEY_INCOME_EXPENSE_TIMESTAMP, allincome_expense.getQuery().get(i).getTimestamp());
                                values_income_expense.put(dataBase.KEY_PRODUCT_PRICE, allincome_expense.getQuery().get(i).getProduct_price());
                                values_income_expense.put(dataBase.KEY_AMOUNT, allincome_expense.getQuery().get(i).getAmount());
                                values_income_expense.put(dataBase.KEY_QUANTITY, allincome_expense.getQuery().get(i).getQuantiy());
                                values_income_expense.put(dataBase.KEY_EXPENSE_ID, dataBase.get_expense_id().get(0));
                                values_income_expense.put(dataBase.KEY_DELETED, "0");
                                a = dataBase.save_income_expense(values_income_expense);
                                Log.d("Income expense", a + "");

                            } else if (allincome_expense.getQuery().get(i).getIncome()) {
                                value_income.put(dataBase.KEY_SAVE_DATE, allincome_expense.getQuery().get(i).getTimestamp());
                                value_income.put(dataBase.KEY_PRODUCT_TYPE_ID, "");
                                value_income.put(dataBase.KEY_SALE_AMOUNT, allincome_expense.getQuery().get(i).getProduct_price());
                                value_income.put(dataBase.KEY_UNIT, allincome_expense.getQuery().get(i).getQuantiy());
                                value_income.put(dataBase.KEY_PRICE_PER_ONE, allincome_expense.getQuery().get(i).getAmount());
                                value_income.put(dataBase.KEY_ON_CREDIT, "0");
                                value_income.put(dataBase.KEY_NOTE, "1");
                                value_income.put(dataBase.KEY_SEND, "0");
                                value_income.put(dataBase.KEY_UUID, pref.getID());
                                value_income.put(dataBase.KEY_EDITED, "0");
                                value_income.put(dataBase.KEY_DELETED, "0");
                                value_income.put(dataBase.KEY_SYNC, 0);
                                dataBase.save_income(value_income);
                                Log.d("On UserLogin Iid", dataBase.get_income_id().get(0).get(0));
                                values_income_expense.put(dataBase.KEY_INCOME, allincome_expense.getQuery().get(i).getIncome() + "");
                                values_income_expense.put(dataBase.KEY_EXPENSE, allincome_expense.getQuery().get(i).getExpense() + "");
                                values_income_expense.put(dataBase.KEY_PRODUCT_NAME, allincome_expense.getQuery().get(i).getProduct_name());
                                values_income_expense.put(dataBase.KEY_INCOME_EXPENSE_TIMESTAMP, allincome_expense.getQuery().get(i).getTimestamp());
                                values_income_expense.put(dataBase.KEY_PRODUCT_PRICE, allincome_expense.getQuery().get(i).getProduct_price());
                                values_income_expense.put(dataBase.KEY_AMOUNT, allincome_expense.getQuery().get(i).getAmount());
                                values_income_expense.put(dataBase.KEY_QUANTITY, allincome_expense.getQuery().get(i).getQuantiy());
                                values_income_expense.put(dataBase.KEY_INCOME_ID, dataBase.get_income_id().get(0).get(0));
                                values_income_expense.put(dataBase.KEY_DELETED, "0");
                                a = dataBase.save_income_expense(values_income_expense);
                                Log.d("Income expense", a + "");

                            }

                        }

                    }

                } else {
                    Log.d("Fail", "parameter");
                    mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                            .setTitle("Fail")
                            .setMessage("Your email and password are incorrect!!!")
                            .setPositiveButton("OK", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mMaterialDialog.dismiss();
                                }
                            });
                    mMaterialDialog.show();
                }
            }

            @Override
            public void onFailure(Call<Income_ExpenseModel> call, Throwable t) {
                Log.d("ONFail", t + "");
                mMaterialDialog = new MaterialDialog(UserLoginActivity.this)
                        .setTitle("Error")
                        .setMessage("Your email and password are incorrect!!!")
                        .setPositiveButton("OK", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mMaterialDialog.dismiss();
                            }
                        });
                mMaterialDialog.show();
            }
        });
    }


    public void getMessage() {
        username = pref.getusername();
        Toast.makeText(UserLoginActivity.this, username, Toast.LENGTH_SHORT).show();
//        com.example.user.onmyanmar.api.Application.USER_NAME
        Call<AllUserMessageDataModel> call = retrofitHelper.message(username);
        call.enqueue(new Callback<AllUserMessageDataModel>() {
            @Override
            public void onResponse(Call<AllUserMessageDataModel> call, Response<AllUserMessageDataModel> response) {
                if (response.isSuccessful()) {
                    allmessage = response.body();
                    Log.d("Size", allmessage.getMessage().size() + "");
                    OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(getApplicationContext(), pref.getDB_NAME());
                    ContentValues values = new ContentValues();
                    if (!allmessage.getMessage().isEmpty()) {
//                        getAllMessage();
                        for (int i = 0; i < allmessage.getMessage().size(); i++) {
                            values.put(KEY_MESSAGE_ID, allmessage.getMessage().get(i).getId());
                            values.put(KEY_SUBJECT, allmessage.getMessage().get(i).getSubject());
                            values.put(KEY_BODY, allmessage.getMessage().get(i).getBody());
                            values.put(KEY_TRIGGER, allmessage.getMessage().get(i).getTrigger());
                            values.put(KEY_TIMESTAMP, allmessage.getMessage().get(i).getTimestamp());
                            values.put(KEY_SEND_BY, allmessage.getMessage().get(i).getSend_by());
                            values.put(KEY_LASTNAME, allmessage.getMessage().get(i).getLastname());
                            values.put(KEY_FIRST_NAME, allmessage.getMessage().get(i).getFirstname());
                            values.put(KEY_SEND, "0");
                            values.put(KEY_SEEN, "0");
                            values.put(KEY_DEL, "0");
                           long a = dataBase.save_message_retro(values);
                            Log.d("A_Message inserted",a+" ");
                        }
                    }

                }
            }

            @Override
            public void onFailure(Call<AllUserMessageDataModel> call, Throwable t) {
                Log.d("fail", "onFailure: ");
            }

        });
    }

    public void getAllMessage() {
    }

}

