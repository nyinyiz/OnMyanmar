package com.example.user.onmyanmar;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.codetroopers.betterpickers.calendardatepicker.CalendarDatePickerDialogFragment;
import com.example.user.onmyanmar.adapter.RecyclerViewAdapter;
import com.example.user.onmyanmar.api.Application;
import com.example.user.onmyanmar.fragement.AlertFragment;
import com.example.user.onmyanmar.fragement.SummaryFragment;
import com.github.clans.fab.FloatingActionMenu;
import com.rubengees.introduction.IntroductionActivity;
import com.rubengees.introduction.IntroductionBuilder;
import com.rubengees.introduction.Option;
import com.rubengees.introduction.Slide;
import com.rubengees.introduction.style.FullscreenStyle;

import java.util.ArrayList;
import java.util.List;

import static android.R.attr.name;
import static android.R.attr.start;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, CalendarDatePickerDialogFragment.OnDateSetListener {

    String name[] = {"Net Worth", "Summary", "Income"};
    CardView updown;
    PrefManager pref;
    ImageView lockout;
    TextView headerText;
    OnMyanmar_DataBase dataBase;
    SQLiteDatabase db;
    TextView user_name;

    private FloatingActionMenu fam;

    private com.github.clans.fab.FloatingActionButton fabup, fabdown;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Refresh();

    }

    public void Refresh()
    {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        pref = new PrefManager(MainActivity.this);
//        lockout = (ImageView) findViewById(R.id.lockout);
        headerText = (TextView) findViewById(R.id.headerText);


        headerText.setText(R.string.app_name);
        //Toast.makeText(MainActivity.this,pref.isLoggedIn()+"",Toast.LENGTH_LONG).show();
        if (!pref.isLoggedIn()) {
            show_intro();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.container, new SummaryFragment());
        ft.commit();

        View headerLayout=navigationView.getHeaderView(0);

        user_name = (TextView) headerLayout.findViewById(R.id.user_name);
        user_name.setText(Application.USER_NAME+"");

        dataBase = new OnMyanmar_DataBase(MainActivity.this, pref.getDB_NAME());




/////////////////////////////////////////////////////////////////////////////
        // Adding Floating Action Button to bottom right of main view
        fabup = (com.github.clans.fab.FloatingActionButton) findViewById(R.id.fab1);
        fabdown = (com.github.clans.fab.FloatingActionButton) findViewById(R.id.fab2);

        fabup.setImageResource(R.drawable.add);
        fabdown.setImageResource(R.drawable.remove);

        //handling each floating action button clicked
        fabup.setOnClickListener(onButtonClick());
        fabdown.setOnClickListener(onButtonClick());

    }


    @Override
    protected void onResume() {
        super.onResume();
        Refresh();

    }

    private View.OnClickListener onButtonClick() {
        return new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (view == fabup) {
                    Intent intent = new Intent(MainActivity.this, AddnewCatagoActivity.class);
                    intent.putExtra("catago", "up");
                    startActivity(intent);
//                    Toast.makeText(UpDownActivity.this,"You click Up",Toast.LENGTH_LONG).show();
                } else if (view == fabdown) {
                    Intent intent = new Intent(MainActivity.this, AddnewCatagoActivity.class);
                    intent.putExtra("catago", "down");
                    startActivity(intent);
//                    Toast.makeText(UpDownActivity.this,"You click down",Toast.LENGTH_LONG).show();
                }


            }

        };

    }


    public void show_intro() {
        new IntroductionBuilder(this)
                .withSlides(generateSlides())
//                .withSlides(new Slide()
//                        .withCustomViewBuilder(new CustomViewBuilderImpl())
//                        .withColorResource(R.color.cyan)
                .introduceMyself();

    }

    private List<Slide> generateSlides() {
        List<Slide> result = new ArrayList<>();
        result.add(new Slide()
                .withTitle("Some title")
                .withDescription("Some description")
                .withColorResource(R.color.green)
                .withImage(R.drawable.imagessss)
        );
        result.add(new Slide()
                .withTitle("Another title")
                .withDescription("Another description")
                .withColorResource(R.color.indigo)
                .withImage(R.drawable.imageaaa)
        );
        result.add(new Slide()
                        .withTitle("Feature is doing something")
//                .withOption(new Option("Enable the feature"))
                        .withDescription("Another description")
                        .withColorResource(R.color.orange)
                        .withImage(R.drawable.imagewww)
        );
        return result;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == IntroductionBuilder.INTRODUCTION_REQUEST_CODE && resultCode == RESULT_OK) {
            String result = "User chose: ";
            for (Option option : data.<Option>getParcelableArrayListExtra(IntroductionActivity.OPTION_RESULT)) {
                result += option.getPosition() + (option.isActivated() ? " enabled" : " disabled");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 12) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission was successfully granted!", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            //super.onBackPressed();
            new AlertDialog.Builder(this)
                    .setTitle("Really Exit?")
                    .setMessage("Are you sure you want to exit?")
                    .setNegativeButton(android.R.string.no, null)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            MainActivity.super.onBackPressed();
                        }
                    }).create().show();
        }
    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.main, menu);
//        return true;
//    }
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        // Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        if (id == R.id.book) {
            ft.replace(R.id.container, new SummaryFragment());
        } else if (id == R.id.sar) {
            ft.replace(R.id.container, new AlertFragment());

        } else if (id == R.id.detail) {
            Intent intent = new Intent(MainActivity.this, UpDownActivity.class);
            startActivity(intent);

        } else if (id == R.id.money) {
            Intent intent = new Intent(MainActivity.this, ChartActivity.class);
            startActivity(intent);

        }  else if (id == R.id.help) {
            show_intro();

        } else if (id == R.id.sync) {
            Intent intent = new Intent(MainActivity.this, SyncActivity.class);
            startActivity(intent);
        }else if (id == R.id.logout)
        {
            pref.logout();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        // Complete the changes added above
        ft.commit();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onDateSet(CalendarDatePickerDialogFragment dialog, int year, int monthOfYear, int dayOfMonth) {
    }
}
