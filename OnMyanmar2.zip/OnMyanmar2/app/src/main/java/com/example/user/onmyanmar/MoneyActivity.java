package com.example.user.onmyanmar;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class MoneyActivity extends AppCompatActivity {

    RecyclerView recyclerview;
    String name[]={"Net Worth","Summary","Income"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money);

        recyclerview = (RecyclerView)findViewById(R.id.recyclerview1);

        recyclerview.setLayoutManager(new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.HORIZONTAL,true));
        RecyclerView.Adapter adapter = new RecyclerViewAdapter(getApplicationContext(),name);

        recyclerview.setAdapter(adapter);
    }

    public static class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
        Context context;ImageView image;
        TextView iname,pricevalue;
        TextView iname2;
        int upordown[];int logos[];String imagename[];String imagename2[];int price[];

        View view1;

        public RecyclerViewAdapter(Context applicationContext,String[]imagename) {
            this.context=applicationContext;

            this.imagename=imagename;

            this.context=applicationContext;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
            view1  = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cardview_item, viewGroup, false);

            return new ViewHolder(view1);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {

            iname.setText(imagename[position]);

        }

        @Override
        public int getItemCount() {
            return 3;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            //        TextView SubjectTextView;
            public ViewHolder(View view) {

                super(view);

                iname = (TextView) view.findViewById(R.id.name);

            }
        }
    }

}
