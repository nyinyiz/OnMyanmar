package com.example.user.onmyanmar.Model;

/**
 * Created by User on 7/10/2017.
 */

public class IncomeModel {
    int amount;

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
