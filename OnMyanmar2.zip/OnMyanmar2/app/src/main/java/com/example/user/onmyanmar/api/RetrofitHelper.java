package com.example.user.onmyanmar.api;



import com.example.user.onmyanmar.Model.AllUserDataModel;

import com.example.user.onmyanmar.Model.Expense_Sync_Model;
import com.example.user.onmyanmar.Model.IncomeModel;

import com.example.user.onmyanmar.Model.Income_ExpenseModel;

import com.example.user.onmyanmar.Model.AllUserMessageDataModel;

import com.example.user.onmyanmar.Model.Income_Sync_Model;
import com.example.user.onmyanmar.Model.Sales_Sync_Model;
import com.example.user.onmyanmar.Model.Sync_Sale_Return;
import com.example.user.onmyanmar.api.ApiService;

import com.google.gson.Gson;

import com.google.gson.GsonBuilder;



import java.net.CookieManager;

import java.net.CookiePolicy;



import okhttp3.JavaNetCookieJar;

import okhttp3.OkHttpClient;

import retrofit2.Call;

import retrofit2.Retrofit;

import retrofit2.converter.gson.GsonConverterFactory;



/**
 * Created by User on 7/4/2017.
 */



public class RetrofitHelper {



    Retrofit retrofit;

    ApiService apiService;

    public CookieManager cookieManager;

    static final String BASE_URL=Application.BASE_URL;



    public RetrofitHelper()

    {

        Gson gson=new GsonBuilder().create();

        cookieManager=new CookieManager();

        cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);

        OkHttpClient okHttpClient= new OkHttpClient.Builder()

                .cookieJar(new JavaNetCookieJar(cookieManager))

                .build();



        retrofit=new Retrofit.Builder()

                .baseUrl(BASE_URL)



                .callFactory(okHttpClient)

                .addConverterFactory(GsonConverterFactory.create(gson))

                .build();

        apiService=retrofit.create(ApiService.class);







    }

    public Call<AllUserDataModel> login(String email, String password)
    {
        return apiService.login(email,password);
    }

    public Call<AllUserMessageDataModel> message(String username)
    {
        return apiService.message(username);
    }

    public Call<IncomeModel> getIncome(String username)
    {
        return apiService.getIncome(username);
    }

    public Call<IncomeModel> getExpense(String user_id)
    {
        return apiService.getExpense(user_id);
    }

    public Call<Income_ExpenseModel> getIncomeExpense(String user_id)
    {
        return apiService.getIncomeExpense(user_id);
    }

    public Call<Income_Sync_Model> getIncome_Sync(String username, String data)
    {
        return apiService.getIncome_Sync(username,data);
    }

    public Call<Sync_Sale_Return> getSale_Sync(String username, String data)
    {
        return apiService.getSale_Sync(username,data);
    }
    public Call<Expense_Sync_Model> getExpense_Sync(String username, String data)
    {
        return apiService.getExpense_Sync(username,data);
    }
}

