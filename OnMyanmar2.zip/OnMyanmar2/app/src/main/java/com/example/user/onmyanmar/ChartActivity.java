package com.example.user.onmyanmar;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.listener.ChartTouchListener;
import com.github.mikephil.charting.listener.OnChartGestureListener;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ChartActivity extends AppCompatActivity implements
        OnChartGestureListener,
        OnChartValueSelectedListener {


    private LineChart mChart;
    private PieChart pieChart;
    Button btn30,btn60,btn90;
    Spinner spinner;
    OnMyanmar_DataBase db;
    PrefManager pref;
    ArrayList<Float> dailyprofit,dailyprofit60,dailyprofit90;

    List<String> startup_budget = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        btn30=(Button)findViewById(R.id.btn30);
        btn60=(Button)findViewById(R.id.btn60);
        btn90=(Button)findViewById(R.id.btn90);

        pref = new PrefManager(getApplicationContext());
        db = new OnMyanmar_DataBase(getApplicationContext(),pref.getDB_NAME());
        dailyprofit =new ArrayList<>();
        dailyprofit60 = new ArrayList<>();
        dailyprofit90 = new ArrayList<>();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String currentDateTime = dateFormat.format(new Date().getTime() + 2 * 24 * 3600 * 1000l); // Find todays date
        Date date1 = null;

        for (int ii=0;ii<30;ii++){

            try {
                date1 = dateFormat.parse(currentDateTime);

            } catch (ParseException e) {
                e.printStackTrace();
            }
            int iii = ii + 1;
            date1 = new Date(date1.getTime() - iii * 24 * 3600 * 1000l);


            List<List<String>> i= null;
            try {
                Log.d("Dates: ",dateFormat.format(date1));
                i = db.get_daily_income(dateFormat.format(date1));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            float incometotal=0,expensetotal=0;

            for(int j=0;j<i.size();j++)
            {
                incometotal += Integer.parseInt(i.get(j).get(0));
            }
            List<List<String>> e= null;
            try {
                e = db.get_daily_expense(dateFormat.format(date1));
            } catch (ParseException e1) {
                e1.printStackTrace();
            }
            for(int z=0;z<e.size();z++)
            {
                expensetotal += Integer.parseInt(e.get(z).get(0));
            }

            Log.d("Income total : ",incometotal+"");
            Log.d("Expense total : ",expensetotal+"");
            float profit = incometotal - expensetotal;
            dailyprofit.add(profit);
            Log.d("Daily Proft value",dailyprofit+"");
        }
        for (int ii=0;ii<60;ii++){

            try {
                date1 = dateFormat.parse(currentDateTime);

            } catch (ParseException e) {
                e.printStackTrace();
            }
            int iii = ii + 1;
            date1 = new Date(date1.getTime() - iii * 24 * 3600 * 1000l);


            List<List<String>> i= null;
            try {
                Log.d("Dates: ",dateFormat.format(date1));
                i = db.get_daily_income(dateFormat.format(date1));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            float incometotal=0,expensetotal=0;

            for(int j=0;j<i.size();j++)
            {
                incometotal += Integer.parseInt(i.get(j).get(0));
            }
            List<List<String>> e= null;
            try {
                e = db.get_daily_expense(dateFormat.format(date1));
            } catch (ParseException e1) {
                e1.printStackTrace();
            }
            for(int z=0;z<e.size();z++)
            {
                expensetotal += Integer.parseInt(e.get(z).get(0));
            }

            Log.d("Income total : ",incometotal+"");
            Log.d("Expense total : ",expensetotal+"");
            float profit = incometotal - expensetotal;
            dailyprofit60.add(profit);
            Log.d("Daily Proft value",dailyprofit+"");
        }
        for (int ii=0;ii<90;ii++){

            try {
                date1 = dateFormat.parse(currentDateTime);

            } catch (ParseException e) {
                e.printStackTrace();
            }
            int iii = ii + 1;
            date1 = new Date(date1.getTime() - iii * 24 * 3600 * 1000l);


            List<List<String>> i= null;
            try {
                Log.d("Dates: ",dateFormat.format(date1));
                i = db.get_daily_income(dateFormat.format(date1));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            float incometotal=0,expensetotal=0;

            for(int j=0;j<i.size();j++)
            {
                incometotal += Integer.parseInt(i.get(j).get(0));
            }
            List<List<String>> e= null;
            try {
                e = db.get_daily_expense(dateFormat.format(date1));
            } catch (ParseException e1) {
                e1.printStackTrace();
            }
            for(int z=0;z<e.size();z++)
            {
                expensetotal += Integer.parseInt(e.get(z).get(0));
            }

            Log.d("Income total : ",incometotal+"");
            Log.d("Expense total : ",expensetotal+"");
            float profit = incometotal - expensetotal;
            dailyprofit90.add(profit);
            Log.d("Daily Proft value",dailyprofit+"");
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        mChart = (LineChart) findViewById(R.id.linechart);
        setData("30");
        mChart.notifyDataSetChanged();
        mChart.invalidate();

        // add data
        btn30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setData("30");
                mChart.notifyDataSetChanged();
                mChart.invalidate();
            }
        });
        btn60.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setData("60");
                mChart.notifyDataSetChanged();
                mChart.invalidate();
            }
        });
        btn90.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setData("90");
                mChart.notifyDataSetChanged();
                mChart.invalidate();
            }
        });


//        startup_budget = db.get_startup_budget();

        mChart.setDrawBorders(false);
        mChart.setDrawGridBackground(false);
        mChart.getXAxis().setDrawGridLines(false);
        mChart.getAxisLeft().setDrawGridLines(false);
        mChart.getAxisRight().setDrawGridLines(false);
//        mChart.getData().setHighlightEnabled(false);
        mChart.setTouchEnabled(true);
        CustomMarkerView mv = new CustomMarkerView (ChartActivity.this, R.layout.tvcontent);
        mChart.setMarkerView(mv);
        mChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                Toast.makeText(ChartActivity.this,mChart.getY()+"Hello Nyi",Toast.LENGTH_LONG).show();
//                Highlight[] highlights=mChart.getHighlighted();
//                mChart.highlightValues(highlights);
            }

            @Override
            public void onNothingSelected() {

            }
        });
        /////////////////////////////////////////////////
//        pieChart = (PieChart) findViewById(R.id.piechart1);
//        pieChart.setUsePercentValues(true);

        ArrayList<PieEntry> yvalues = new ArrayList<>();
        yvalues.add(new PieEntry(50f, 0));
        yvalues.add(new PieEntry(25f, 1));
        yvalues.add(new PieEntry(25f, 2));
//        yvalues.add(new PieEntry(25f, 3));
//        yvalues.add(new PieEntry(23f, 4));
//        yvalues.add(new PieEntry(17f, 5));

        PieDataSet dataSet = new PieDataSet(yvalues,"Election Results");

        ArrayList<String> xVals = new ArrayList<String>();

        xVals.add("January");
        xVals.add("February");
        xVals.add("March");
//        xVals.add("April");
//        xVals.add("May");
//        xVals.add("June");

        PieData data = new PieData(dataSet);

        data.setValueFormatter(new PercentFormatter());
//        pieChart.setData(data);
//
//        pieChart.setDrawHoleEnabled(true);
//        pieChart.setTransparentCircleRadius(58f);
//
//
//        pieChart.setHoleRadius(30f);
        dataSet.setColors(ColorTemplate.VORDIPLOM_COLORS);

        data.setValueTextSize(13f);
        data.setValueTextColor(Color.DKGRAY);


//        pieChart.setOnChartValueSelectedListener(this);
        /////////////////////////////////////////////////////////////////////
    }

    // This is used to store x-axis values
    private ArrayList<String> setXAxisValues(){
        ArrayList<String> xVals = new ArrayList<String>();
        xVals.add("1K");
        xVals.add("10");
        xVals.add("15");
        xVals.add("10");
        xVals.add("20");
        xVals.add("15");
        xVals.add("25");
        xVals.add("30");
        xVals.add("20");
        xVals.add("10");

        return xVals;
    }

    // This is used to store Y-axis values
    private ArrayList<Entry> setYAxisValues(String totalday){
        ArrayList<Entry> yVals = new ArrayList<Entry>();
        if(totalday.equals("30"))
        for(int g=0;g<dailyprofit.size();g++)
        {
            yVals.add(new Entry(g+1,dailyprofit.get(g)));
            Log.d("30days added","done");
        }
        if(totalday.equals("60"))
            for(int g=0;g<dailyprofit60.size();g++)
            {
                yVals.add(new Entry(g+1,dailyprofit60.get(g)));
                Log.d("60days added","done");
            }
        if(totalday.equals("90"))
            for(int g=0;g<dailyprofit90.size();g++)
            {
                yVals.add(new Entry(g+1,dailyprofit90.get(g)));
                Log.d("60days added","done");
            }


        return yVals;
    }
    private void setData(String totalday) {
        Toast.makeText(getApplicationContext(),totalday+" setData",Toast.LENGTH_LONG).show();
        ArrayList<String> xVals = setXAxisValues();

        ArrayList<Entry> yVals = setYAxisValues(totalday);

        LineDataSet set1;

        // create a dataset and give it a type
        set1 = new LineDataSet(yVals, "DataSet 1");
        set1.setFillAlpha(110);
        // set1.setFillColor(Color.RED);

        // set the line to be drawn like this "- - - - - -"
        // set1.enableDashedLine(10f, 5f, 0f);
        // set1.enableDashedHighlightLine(10f, 5f, 0f);
        set1.setColor(Color.BLACK);
        set1.setCircleColor(Color.BLACK);
        set1.setLineWidth(1f);
        set1.setCircleRadius(3f);
        set1.setDrawCircleHole(false);
        set1.setValueTextSize(9f);
        set1.setDrawFilled(true);
        set1.setDrawValues(false);
        set1.setDrawHighlightIndicators(true);
        set1.setMode(LineDataSet.Mode.CUBIC_BEZIER);

//     set1.setDrawCubic(true);

        ArrayList<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
        dataSets.add(set1); // add the datasets

        // create a data object with the datasets
        LineData data = new LineData(dataSets);

        data.setDrawValues(false);
        // set data
        mChart.setData(data);
    }

    @Override
    public void onChartGestureStart(MotionEvent me, ChartTouchListener.ChartGesture lastPerformedGesture) {
        Log.i("Gesture", "START, x: " + me.getX() + ", y: " + me.getY());
    }

    @Override
    public void onChartGestureEnd(MotionEvent me, ChartTouchListener.ChartGesture lastPerformedGesture) {
        Log.i("Gesture", "END, lastGesture: " + lastPerformedGesture);

        // un-highlight values after the gesture is finished and no single-tap
        if(lastPerformedGesture != ChartTouchListener.ChartGesture.SINGLE_TAP)
            // or highlightTouch(null) for callback to onNothingSelected(...)
            mChart.highlightValues(null);
    }

    @Override
    public void onChartLongPressed(MotionEvent me) {
        Log.i("LongPress", "Chart longpressed.");
    }

    @Override
    public void onChartDoubleTapped(MotionEvent me) {
        Log.i("DoubleTap", "Chart double-tapped.");
    }

    @Override
    public void onChartSingleTapped(MotionEvent me) {
        Log.i("SingleTap", "Chart single-tapped.");
        Toast.makeText(ChartActivity.this,"SingleTap"+"Chart single-tapped.",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onChartFling(MotionEvent me1, MotionEvent me2, float velocityX, float velocityY) {
        Log.i("Fling", "Chart flinged. VeloX: "
                + velocityX + ", VeloY: " + velocityY);
    }

    @Override
    public void onChartScale(MotionEvent me, float scaleX, float scaleY) {
        Log.i("Scale / Zoom", "ScaleX: " + scaleX + ", ScaleY: " + scaleY);
    }

    @Override
    public void onChartTranslate(MotionEvent me, float dX, float dY) {
        Log.i("Translate / Move", "dX: " + dX + ", dY: " + dY);
    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {
//        Log.i("Entry selected", e.toString());
////        Log.i("LOWHIGH", "low: " + mChart.getLowestVisibleXIndex()
////                + ", high: " + mChart.getHighestVisibleXIndex());
//
//        Log.i("MIN MAX", "xmin: " + mChart.getXChartMin()
//                + ", xmax: " + mChart.getXChartMax()
//                + ", ymin: " + mChart.getYChartMin()
//                + ", ymax: " + mChart.getYChartMax());
        Toast.makeText(ChartActivity.this,mChart.getXChartMax()+ " "+mChart.getYChartMax()+" ",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected() {
        Log.i("Nothing selected", "Nothing selected.");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.android_action_bar_spinner_menu, menu);
        MenuItem item = menu.findItem(R.id.spinner);
        spinner = (Spinner) MenuItemCompat.getActionView(item);

        // Defined Array values to show in ListView
        String[] values = new String[] { "Last 30 days",
                "Last 60 days",
                "Last 90 days"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0: setData("30");
                        mChart.notifyDataSetChanged();
                        mChart.invalidate();
                        Toast.makeText(getApplicationContext(),position+"",Toast.LENGTH_LONG).show();
                        break;
                    case 1: setData("60");
                        mChart.notifyDataSetChanged();
                        mChart.invalidate();
                        break;
//                        Toast.makeText(getApplicationContext(),position+"",Toast.LENGTH_LONG).show();
                    case 2: setData("90");
                        mChart.notifyDataSetChanged();
                        mChart.invalidate();
                        break;
//                        Toast.makeText(getApplicationContext(),position+"",Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                setData("30");
                mChart.notifyDataSetChanged();
                mChart.invalidate();
            }
        });
        return true;
    }
}
