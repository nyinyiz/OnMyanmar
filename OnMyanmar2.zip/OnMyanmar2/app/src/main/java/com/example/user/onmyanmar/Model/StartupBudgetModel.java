package com.example.user.onmyanmar.Model;

/**
 * Created by pyaesone on 7/14/17.
 */

public class StartupBudgetModel {

    int id;
    int user_id;
    int installation_fees;
    int starting_inventory;
    int other_fees;
    int advanced_rent;
    int license;
    int advertising;
    int operating_cash;
    String start_date;
    String timestamp;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getInstallation_fees() {
        return installation_fees;
    }

    public void setInstallation_fees(int installation_fees) {
        this.installation_fees = installation_fees;
    }

    public int getStarting_inventory() {
        return starting_inventory;
    }

    public void setStarting_inventory(int starting_inventory) {
        this.starting_inventory = starting_inventory;
    }

    public int getOther_fees() {
        return other_fees;
    }

    public void setOther_fees(int other_fees) {
        this.other_fees = other_fees;
    }

    public int getAdvanced_rent() {
        return advanced_rent;
    }

    public void setAdvanced_rent(int advanced_rent) {
        this.advanced_rent = advanced_rent;
    }

    public int getLicense() {
        return license;
    }

    public void setLicense(int license) {
        this.license = license;
    }

    public int getAdvertising() {
        return advertising;
    }

    public void setAdvertising(int advertising) {
        this.advertising = advertising;
    }

    public int getOperating_cash() {
        return operating_cash;
    }

    public void setOperating_cash(int operating_cash) {
        this.operating_cash = operating_cash;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

}
