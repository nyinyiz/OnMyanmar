package com.example.user.onmyanmar.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.user.onmyanmar.Model.UserMessageDataModel;
import com.example.user.onmyanmar.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 6/30/2017.
 */


public class RecyclerViewAdapterForAlertFragment extends RecyclerView.Adapter<RecyclerViewAdapterForAlertFragment.ViewHolder> {
    Context context;
    int position;
    String hour[];
    String title[];
    int icon[];
    Button clearall;

    View view1;
    List<List<String>> message;

    public RecyclerViewAdapterForAlertFragment(Context applicationContext,List<List<String>> message) {
        this.context=applicationContext;
        this.message=message;

    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        view1  = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cardview_alert, viewGroup, false);
//        Log.d("Hour Values: ",hour.length+"");
        return new ViewHolder(view1);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        this.position = position;

//        Toast.makeText(context,message.get(position).get(3),Toast.LENGTH_LONG).show();
        Log.d("Message",message.get(position).get(3)+"");

        holder.alertName.setText(message.get(position).get(3));
        holder.alertbody.setText(message.get(position).get(4));
        holder.alertid.setText(message.get(position).get(0));
//        holder.alerticon.setImageResource(icon[position]);
//        if(Integer.valueOf(hour[position])<=0)
//        {
//            holder.colorleft.setBackgroundColor(Color.BLUE);
//        }
        if(message.get(position).get(3).equals("Inactive Expense")||message.get(position).get(3).equals("Inactive Income"))
        {
            holder.alerticon.setImageResource(R.drawable.inactive);
        }
        else if(message.get(position).get(3).equals("Over Budget"))
        {
            holder.alerticon.setImageResource(R.drawable.budget_overflow);
        }
        else if(message.get(position).get(3).equals("Low Sale"))
        {
            holder.alerticon.setImageResource(R.drawable.low_sale);
        }
        else if(message.get(position).get(3).equals("Low Cash"))
        {
            holder.alerticon.setImageResource(R.drawable.low_balance);
        }
        else if(message.get(position).get(3).equals("Stagnant Product"))
        {
            holder.alerticon.setImageResource(R.drawable.product);
        }
        else if(message.get(position).get(3).equals("Upcoming payment"))
        {
            holder.alerticon.setImageResource(R.drawable.income_payment);
        }
        else
        {
            holder.alerticon.setImageResource(R.drawable.alert);
        }
    }

    @Override
    public int getItemCount() {
        return message.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //        TextView SubjectTextView;
        CardView cardView;
        TextView lasttime,alertName,colorleft,alertbody,alertid;
        ImageView alerticon;
        public ViewHolder(View view) {

            super(view);
            alertName = (TextView) view.findViewById(R.id.alertName);
            alertbody = (TextView) view.findViewById(R.id.alertbody);
            alertid = (TextView) view.findViewById(R.id.alertid);
//            lasttime = (TextView) view.findViewById(R.id.lasttime);
//            colorleft = (TextView) view.findViewById(R.id.colorleft);
//            cardView = (CardView) view.findViewById(R.id.alertcard);
            alerticon=(ImageView)view.findViewById(R.id.alerticon);

        }
    }
}
