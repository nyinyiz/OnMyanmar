package com.example.user.onmyanmar.fragement;

import android.app.Application;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.user.onmyanmar.Model.AllUserMessageDataModel;
import com.example.user.onmyanmar.OnMyanmar_DataBase;
import com.example.user.onmyanmar.PrefManager;
import com.example.user.onmyanmar.R;
import com.example.user.onmyanmar.adapter.RecyclerViewAdapter;
import com.example.user.onmyanmar.adapter.RecyclerViewAdapterForAlertFragment;
import com.example.user.onmyanmar.api.RetrofitHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_BODY;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_DEL;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_FIRST_NAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_LASTNAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_MESSAGE_ID;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_MESSAGE_TABLE;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEEN;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEND;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEND_BY;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SUBJECT;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_TIMESTAMP;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_TRIGGER;

/**
 * Created by pyaesone on 7/10/17.
 */

public class AlertFragment extends Fragment {

    int listsize;
    RecyclerView simpleList;View v;
    SwipeRefreshLayout mSwipeRefreshLayout;
    RetrofitHelper retrofitHelper;
    PrefManager prefManager;
    OnMyanmar_DataBase dataBase;
    ContentValues values;
    ArrayList<String> messagelist;
    List<List<String>> AlertList;
    RecyclerView.LayoutManager RecyclerViewLayoutManager;
    ArrayList<Integer> messagedeleted;
    AllUserMessageDataModel allmessage;
    Button clearall;
    String username;
    RecyclerViewAdapterForAlertFragment alertAdapter;

    public AlertFragment() {

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        retrofitHelper= new RetrofitHelper();
        messagelist = new ArrayList<String>();

        prefManager = new PrefManager(getContext());
        username=prefManager.getusername();
        Log.d("Username from pref",prefManager.getusername());

        dataBase = new OnMyanmar_DataBase(getContext(),prefManager.getDB_NAME());

//        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                // Refresh items
//                refreshItems();
//            }
//        });



        messagedeleted = new ArrayList<>();

    }
    void refreshItems() {
        // Load items
        // ...

        // Load complete
        onItemsLoadComplete();
    }

    void onItemsLoadComplete() {
        // Update the adapter and notify data set changed
        // ...

        // Stop refresh animation
        mSwipeRefreshLayout.setRefreshing(false);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_sar_fargment,container,false);
        clearall= (Button)v.findViewById(R.id.clearall);
        clearall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clear();
                dataBase.update_alert_del_all();
            }
        });
//        getMessage();
        alert_show();

        values = new ContentValues();
        v.setClickable(true);
        return v;
    }
    public void clear() {
        int size = this.AlertList.size();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                this.AlertList.remove(0);
            }

            alertAdapter.notifyDataSetChanged();
        }
    }

public void alert_show()
{
        simpleList = (RecyclerView) v.findViewById(R.id.alertlist);

        RecyclerViewLayoutManager = new LinearLayoutManager(getContext());
        simpleList.setLayoutManager(RecyclerViewLayoutManager);
        AlertList = dataBase.get_latest_message();
        Log.d("Alert List",AlertList+"");
        alertAdapter = new RecyclerViewAdapterForAlertFragment(getContext(),AlertList);
        simpleList.setAdapter(alertAdapter);
        // init swipe to dismiss logic
        ItemTouchHelper swipeToDismissTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                // callback for drag-n-drop, false to skip this feature
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                // callback for swipe to dismiss, removing item from data and adapter
                messagedeleted.add(viewHolder.getAdapterPosition());
                AlertList.remove(viewHolder.getAdapterPosition());
                dataBase.update_alert_del(Integer.valueOf(dataBase.get_latest_message().get(viewHolder.getAdapterPosition()).get(0)));
                Toast.makeText(getContext(), messagedeleted+"", Toast.LENGTH_SHORT).show();
                listsize -= 1;
//                                alertAdapter.notifyItemRangeRemoved(0,listsize);
                alertAdapter.notifyDataSetChanged();

            }
        });
        swipeToDismissTouchHelper.attachToRecyclerView(simpleList);

}




}
