package com.example.user.onmyanmar.Model;

/**
 * Created by pyaesone on 7/21/17.
 */

public class IncomeSyncResultModel {

    //            "result": {
//        "0": {
//            "uuid": "99fb2667-55df-4fc",
//                    "id": 108,
//                    "status": "true"
//        },
//        "1": {
//            "uuid": "99fb2667-55df-4f23",
//                    "id": 109,
//                    "status": "true"
//        }
//    }


}
