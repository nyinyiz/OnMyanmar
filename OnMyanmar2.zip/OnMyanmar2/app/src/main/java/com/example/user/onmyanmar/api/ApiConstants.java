package com.example.user.onmyanmar.api;

/**
 * Created by pyaesone on 7/21/17.
 */

public class ApiConstants {

    public static final String mobile = "mobile/";
    public static final String income_post = mobile+"income";
    public static final String expense_post = mobile+"expense";
    public static final String sale_post = mobile+"sales";


}
