package com.example.user.onmyanmar;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.StringRes;

/**
 * Created by KMT on 2/10/2016.
 */
public class PrefManager {
    // Shared Preferences
    SharedPreferences pref;

    // Editor for Shared preferences
    SharedPreferences.Editor editor;

    // Context
    Context _context;

    // Shared pref mode
    int PRIVATE_MODE = 0;

    // Shared pref file name
    private static final String PREF_NAME = "ON Myanmar";

    // All Shared Preferences Keys
    private static final String IS_LOGIN = "IsLoggedIn";

    // Email address (make variable public to access from outside)
    public static final String KEY_ID = "user_id";
    public static final String KEY_UUID = "uuid";
    public static final String USER_NAME="user_name";

    public static final String CASH_HAND="cash";

    private String DB_NAME = "onmyanmar_db_";
//private String DB_NAME="onmyanmar";
    // Constructor
    public PrefManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    /**
     * Create login session
     */
    public void createLoginSession(int id,String name,String uuid) {
        // Storing login value as TRUE
        editor.putBoolean(IS_LOGIN, true);

        // Storing email in pref
        editor.putInt(KEY_ID, id);

        editor.putString(USER_NAME,name);

        // Storing email in pref
        editor.putString(KEY_UUID, uuid);

        // commit changes
        editor.commit();

    }


    public String getusername()
    {
        return pref.getString(USER_NAME,"");
    }

    public void cash_on_hand(String cashhand)
    {
        editor.putString(CASH_HAND,cashhand);
    }
    public String get_cash_on_hand()
    {
        return pref.getString(CASH_HAND,"");
    }

    public Integer getID() {
        return pref.getInt(KEY_ID, 0);
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(IS_LOGIN, false);
    }

    public String getDB_NAME() { return DB_NAME+getID(); }

    public void logout() {
        editor.clear();
        editor.commit();
    }

    public String getUUID() {
        return pref.getString(KEY_UUID,"");
    }
}