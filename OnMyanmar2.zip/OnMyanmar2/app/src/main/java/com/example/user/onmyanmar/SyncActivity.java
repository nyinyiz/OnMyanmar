package com.example.user.onmyanmar;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.akexorcist.roundcornerprogressbar.RoundCornerProgressBar;
import com.example.user.onmyanmar.Model.AllUserDataModel;
import com.example.user.onmyanmar.Model.AllUserMessageDataModel;
import com.example.user.onmyanmar.Model.DataModel;
import com.example.user.onmyanmar.Model.DataModel_expense;
import com.example.user.onmyanmar.Model.Expense_Sync_Model;
import com.example.user.onmyanmar.Model.IncomeModel;
import com.example.user.onmyanmar.Model.IncomeSyncResultModel;
import com.example.user.onmyanmar.Model.Income_ExpenseModel;
import com.example.user.onmyanmar.Model.Income_Sync_Model;
import com.example.user.onmyanmar.Model.NewExpenseSyncModel;
import com.example.user.onmyanmar.Model.NewIncomeSyncModel;
import com.example.user.onmyanmar.Model.Sale_Sync;
import com.example.user.onmyanmar.Model.Sales_Sync_Model;
import com.example.user.onmyanmar.Model.Sales_Sync_data;
import com.example.user.onmyanmar.Model.Sync_Sale_Return;
import com.example.user.onmyanmar.adapter.RecyclerViewAdapter;
import com.example.user.onmyanmar.adapter.RecyclerViewAdapterForAlertFragment;
import com.example.user.onmyanmar.api.Application;
import com.example.user.onmyanmar.api.RetrofitHelper;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import me.drakeet.materialdialog.MaterialDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_BODY;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_DEL;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_FIRST_NAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_LASTNAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_MESSAGE_ID;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEEN;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEND;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SEND_BY;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_SUBJECT;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_TIMESTAMP;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_TRIGGER;

public class SyncActivity extends AppCompatActivity {


    RetrofitHelper retrofitHelper;

    Income_Sync_Model income_amount;
    Income_ExpenseModel allincome_expense;

    Sync_Sale_Return sale_sync;

    Expense_Sync_Model expense_amount;

    AllUserDataModel alluser;
    AllUserDataModel allUserDataModel;

    AllUserMessageDataModel allmessage;

    MaterialDialog mMaterialDialog;
    PrefManager pref;

    JSONArray userdata = null;
    JSONObject jsonObject;

    String username;
    ContentValues values;

    OnMyanmar_DataBase dataBase;

    RoundCornerProgressBar roundCornerProgressBar;
    Button synctest;
    TextView sync_name;
    String uuid;
    int progress = 0,user_id;

    List<List<String>> result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sync_);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);


        retrofitHelper = new RetrofitHelper();
        pref = new PrefManager(SyncActivity.this);
        username = pref.getusername();
        user_id = pref.getID();
        uuid = pref.getUUID();
        dataBase = new OnMyanmar_DataBase(SyncActivity.this, pref.getDB_NAME());

        sync_name= (TextView) findViewById(R.id.sync_name);
        synctest= (Button) findViewById(R.id.synctest);


        roundCornerProgressBar = (RoundCornerProgressBar) findViewById(R.id.roundCornerProgressBar);
        roundCornerProgressBar.setProgress(progress);
        synctest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // SELECT * FROM INCOME WHERE SYNC = 0

//                sync_income();
//
//                sync_expense();

                sync_catago_sales();

            }
        });


    }

    public void sync_income()
    {
        result = new ArrayList<List<String>>();

        result = dataBase.get_income_sync();

        DataModel dataModels = new DataModel();
        ArrayList<NewIncomeSyncModel> newIncomeSync=new ArrayList<NewIncomeSyncModel>();



        for(int i=0;i<result.size();i++)
        {
            NewIncomeSyncModel newIncomeSyncModel = new NewIncomeSyncModel();
            for(int ii=0;ii<result.get(i).size();ii++)
            {
                newIncomeSyncModel.setUser_id(user_id+"");
                newIncomeSyncModel.setUuid(result.get(i).get(0));
                newIncomeSyncModel.setSale_id(result.get(i).get(1));
                newIncomeSyncModel.setAmount(result.get(i).get(2));
                newIncomeSyncModel.setOn_credit("0");
                newIncomeSyncModel.setQuantity(result.get(i).get(3));

                if (result.get(i).get(4) != null) {
                    newIncomeSyncModel.setDescr(result.get(i).get(4));
                } else {
                    newIncomeSyncModel.setDescr(" ");
                }
                newIncomeSyncModel.setNote(result.get(i).get(5));
                if (result.get(i).get(6) != null) {
                    newIncomeSyncModel.setSubmitted_at(result.get(i).get(6));
                } else {
                    newIncomeSyncModel.setSubmitted_at(" ");
                }

            }

            Log.d("Sync state",result.get(i).get(7)+"");
            Log.d("result"+i,result.get(i).get(0)+"");
            newIncomeSync.add(newIncomeSyncModel);
        }
        dataModels.setData(newIncomeSync);

//                Log.d("NewIncomeExpense",dataModels.getData().get(0)+"");
//                Log.d("Income_Sync",result+"");

        Gson gson = new Gson();
        String data = gson.toJson(dataModels);
        Log.d("Gson array",data+"");
        if (newIncomeSync.isEmpty())
        {
            Toast.makeText(SyncActivity.this,"Already Update",Toast.LENGTH_LONG).show();
        }else {
            getIncome(username,data);

        }
    }
    public void sync_catago_sales()
    {
        result = new ArrayList<List<String>>();

        result = dataBase.get_sales_sync();

        Sales_Sync_data dataModels = new Sales_Sync_data();
        ArrayList<Sale_Sync> newIncomeSync=new ArrayList<Sale_Sync>();



        for(int i=0;i<result.size();i++)
        {
            Sale_Sync newIncomeSyncModel = new Sale_Sync();
            for(int ii=0;ii<result.get(i).size();ii++)
            {

                newIncomeSyncModel.setId(result.get(i).get(0));
                newIncomeSyncModel.setName(result.get(i).get(1));


            }

            Log.d("Sync state",result.get(i).get(2)+"");

            newIncomeSync.add(newIncomeSyncModel);
        }
        dataModels.setData(newIncomeSync);

//                Log.d("NewIncomeExpense",dataModels.getData().get(0)+"");
//                Log.d("Income_Sync",result+"");

        Gson gson = new Gson();
        String data = gson.toJson(dataModels);
        Log.d("Gson array",data+"");
        if (newIncomeSync.isEmpty())
        {
            Toast.makeText(SyncActivity.this,"Already Update",Toast.LENGTH_LONG).show();
        }else {
            getSales(username,data);

        }
    }

    public void getIncome(String username, final String data) {

        Call<Income_Sync_Model> call = retrofitHelper.getIncome_Sync(username,data);
        call.enqueue(new Callback<Income_Sync_Model>() {
            @Override
            public void onResponse(Call<Income_Sync_Model> call, Response<Income_Sync_Model> response) {
                if (response.isSuccessful()) {

                    income_amount = response.body();



                    if (income_amount.getResult().isEmpty())
                    {
                        mMaterialDialog = new MaterialDialog(SyncActivity.this)
                                .setTitle("Sorry")
                                .setMessage("Book are not in this genre!!!")
                                .setPositiveButton("OK", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mMaterialDialog.dismiss();
                                    }
                                });
                        mMaterialDialog.show();
                    }else
                    {
                        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(SyncActivity.this, pref.getDB_NAME());
                        ContentValues values = new ContentValues();

                        for (int i = 0; i < income_amount.getResult().size(); i++) {
                            values.put(dataBase.KEY_INCOME_ID, income_amount.getResult().get(i).getId());
                            values.put(dataBase.KEY_SYNC,1+"");
                            dataBase.update_income_by_uuid(values,income_amount.getResult().get(i).getUuid());
                            Toast.makeText(SyncActivity.this,"Income Sync Successful",Toast.LENGTH_LONG).show();
                        }

                    }

                    Log.d("User_id",income_amount.getUser_id());
                    Log.d("UUID",income_amount.getUuid());
                    progress += 50;
                    roundCornerProgressBar.setProgress(progress);

                } else {
                    Log.d("Fail", "parameter");
                }
            }


            @Override
            public void onFailure(Call<Income_Sync_Model> call, Throwable t) {
                Log.d("ONFail", t + "");
            }
        });

    }

    public void getSales(String username,final String data)
    {
        Call<Sync_Sale_Return> call = retrofitHelper.getSale_Sync(username,data);
        call.enqueue(new Callback<Sync_Sale_Return>() {
            @Override
            public void onResponse(Call<Sync_Sale_Return> call, Response<Sync_Sale_Return> response) {
                if (response.isSuccessful()) {

                    sale_sync = response.body();

                    if (sale_sync.getResult().isEmpty())
                    {
                        mMaterialDialog = new MaterialDialog(SyncActivity.this)
                                .setTitle("Sorry")
                                .setMessage("Book are not in this genre!!!")
                                .setPositiveButton("OK", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mMaterialDialog.dismiss();
                                    }
                                });
                        mMaterialDialog.show();
                    }else
                    {
                        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(SyncActivity.this, pref.getDB_NAME());
                        ContentValues values = new ContentValues();

                        for (int i = 0; i < sale_sync.getResult().size(); i++) {

                            values.put(dataBase.KEY_PRODUCT_TYPE_ID, sale_sync.getResult().get(i).getId());
                            values.put(dataBase.KEY_SYNC,1+"");

                            dataBase.update_sale_by_id(values,sale_sync.getResult().get(i).getId());

                            Toast.makeText(SyncActivity.this,"Sale Sync Successful",Toast.LENGTH_LONG).show();
                        }

                    }

//                    Log.d("User_id",income_amount.getUser_id());
//                    Log.d("UUID",income_amount.getUuid());

                    progress += 50;
                    roundCornerProgressBar.setProgress(progress);

                } else {
                    Log.d("Fail", "parameter");
                }
            }


            @Override
            public void onFailure(Call<Sync_Sale_Return> call, Throwable t) {
                Log.d("ONFail", t + "");
            }
        });
    }
    public void sync_expense()
    {
        result = new ArrayList<List<String>>();

        result = dataBase.get_expense_sync();

        DataModel_expense dataModels = new DataModel_expense();
        ArrayList<NewExpenseSyncModel> newExpenseSync=new ArrayList<NewExpenseSyncModel>();



        for(int i=0;i<result.size();i++)
        {
            NewExpenseSyncModel newExpenseSyncModel = new NewExpenseSyncModel();
            for(int ii=0;ii<result.get(i).size();ii++)
            {
                newExpenseSyncModel.setUser_id(user_id+"");
                newExpenseSyncModel.setUuid(result.get(i).get(0));
                newExpenseSyncModel.setExpense_type_id(result.get(i).get(1));
                newExpenseSyncModel.setAmount(result.get(i).get(2));
                newExpenseSyncModel.setOn_credit("0");
//                newExpenseSyncModel.setQuantity(result.get(i).get(3));
                if (result.get(i).get(3) != null) {
                    newExpenseSyncModel.setDescr(result.get(i).get(3));
                } else {
                    newExpenseSyncModel.setDescr(" ");
                }
                if (result.get(i).get(4) != null)
                {
                    newExpenseSyncModel.setNote(result.get(i).get(4));
                }else {
                    newExpenseSyncModel.setNote(" ");
                }

                if (result.get(i).get(5) != null) {
                    newExpenseSyncModel.setSubmitted_at(result.get(i).get(5));
                } else {
                    newExpenseSyncModel.setSubmitted_at(" ");
                }

            }

            Log.d("Sync state",result.get(i).get(6)+"");
            Log.d("result"+i,result.get(i).get(0)+"");
            newExpenseSync.add(newExpenseSyncModel);
        }
        dataModels.setData(newExpenseSync);

//                Log.d("NewIncomeExpense",dataModels.getData().get(0)+"");
//                Log.d("Income_Sync",result+"");

        Gson gson = new Gson();
        String data = gson.toJson(dataModels);
        Log.d("Gson array",data+"");
        if (newExpenseSync.isEmpty())
        {
            Toast.makeText(SyncActivity.this,"Already Update",Toast.LENGTH_LONG).show();
        }else {
            getExpense(username,data);
        }
    }

    public void getExpense(String username, final String data) {

        Log.d("User name",username);
        Log.d("Data",data);
        Call<Expense_Sync_Model> call = retrofitHelper.getExpense_Sync(username,data);
        call.enqueue(new Callback<Expense_Sync_Model>() {
            @Override
            public void onResponse(Call<Expense_Sync_Model> call, Response<Expense_Sync_Model> response) {
                if (response.isSuccessful()) {

                    expense_amount = response.body();



                    if (expense_amount.getResult().isEmpty())
                    {
                        mMaterialDialog = new MaterialDialog(SyncActivity.this)
                                .setTitle("Sorry")
                                .setMessage("Book are not in this genre!!!")
                                .setPositiveButton("OK", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mMaterialDialog.dismiss();
                                    }
                                });
                        mMaterialDialog.show();
                    }else
                    {
                        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(SyncActivity.this, pref.getDB_NAME());
                        ContentValues values = new ContentValues();

                        for (int i = 0; i < expense_amount.getResult().size(); i++) {
                            values.put(dataBase.KEY_EXPENSE_ID, expense_amount.getResult().get(i).getId());
                            values.put(dataBase.KEY_SYNC, 1 +"");
                            dataBase.update_expense_by_uuid(values,expense_amount.getResult().get(i).getUuid());
                            Toast.makeText(SyncActivity.this,"Expense Sync Successful",Toast.LENGTH_LONG).show();
                        }




                    }


//
                    Log.d("User_id",expense_amount.getUser_id());
                    Log.d("UUID",expense_amount.getUuid());
                    progress += 50;
                    roundCornerProgressBar.setProgress(progress);

                } else {
                    Log.d("Fail", "parameter");
                }
            }


            @Override
            public void onFailure(Call<Expense_Sync_Model> call, Throwable t) {
                Log.d("ONFail", t + "");
            }
        });

    }

    public void getIncomeExpense(String user_id) {
        Call<Income_ExpenseModel> call = retrofitHelper.getIncomeExpense(user_id);
        call.enqueue(new Callback<Income_ExpenseModel>() {
            @Override
            public void onResponse(Call<Income_ExpenseModel> call, Response<Income_ExpenseModel> response) {
                if (response.isSuccessful()) {
                    allincome_expense = response.body();
                    if (allincome_expense.getQuery().isEmpty()) {
                        mMaterialDialog = new MaterialDialog(SyncActivity.this)
                                .setTitle("Sorry")
                                .setMessage("Book are not in this genre!!!")
                                .setPositiveButton("OK", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mMaterialDialog.dismiss();
                                    }
                                });
                        mMaterialDialog.show();
                    } else {
                        Log.d("Size", allincome_expense.getQuery().size() + "");
                        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(SyncActivity.this, pref.getDB_NAME());
                        ContentValues values = new ContentValues();
                        for (int i = 0; i < allincome_expense.getQuery().size(); i++) {
                            values.put(dataBase.KEY_INCOME, allincome_expense.getQuery().get(i).getIncome());
                            values.put(dataBase.KEY_EXPENSE, allincome_expense.getQuery().get(i).getExpense());
                            values.put(dataBase.KEY_PRODUCT_NAME, allincome_expense.getQuery().get(i).getProduct_name());
                            values.put(dataBase.KEY_INCOME_EXPENSE_TIMESTAMP, allincome_expense.getQuery().get(i).getTimestamp());
                            values.put(dataBase.KEY_PRODUCT_PRICE, allincome_expense.getQuery().get(i).getProduct_price());

                            dataBase.save_income_expense(values);

                        }


                    }

                } else {

                    Log.d("Fail", "parameter");
                    mMaterialDialog = new MaterialDialog(SyncActivity.this)
                            .setTitle("Fail")
                            .setMessage("Your email and password are incorrect!!!")
                            .setPositiveButton("OK", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mMaterialDialog.dismiss();
                                }
                            });
                    mMaterialDialog.show();
                }
            }

            @Override
            public void onFailure(Call<Income_ExpenseModel> call, Throwable t) {
                Log.d("ONFail", t + "");
                mMaterialDialog = new MaterialDialog(SyncActivity.this)
                        .setTitle("Error")
                        .setMessage("Your email and password are incorrect!!!")
                        .setPositiveButton("OK", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mMaterialDialog.dismiss();
                            }
                        });
                mMaterialDialog.show();
            }
        });
    }


    public void logingetall(String email, String password) {


        Call<AllUserDataModel> call = retrofitHelper.login(email, password);

        call.enqueue(new Callback<AllUserDataModel>() {

            @Override

            public void onResponse(Call<AllUserDataModel> call, Response<AllUserDataModel> response) {


                if (response.isSuccessful()) {

                    allUserDataModel = response.body();

                    pref.createLoginSession(Integer.parseInt(allUserDataModel.getUser_data().getUser_id()), allUserDataModel.getUser_data().getUsername(),allUserDataModel.getUser_data().getUuid());

                    insert_user_data();
//                    insert_sale();


                    Log.d("****Pref", pref.getDB_NAME() + " AND " + pref.getID());

                    Intent intent = new Intent(SyncActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();

                } else {

                    Log.d("Fail", "parameter");

                    mMaterialDialog = new MaterialDialog(SyncActivity.this)
                            .setTitle("Fail")
                            .setMessage("Your email and password are incorrect!!!")
                            .setPositiveButton("OK", new View.OnClickListener() {

                                @Override

                                public void onClick(View v) {
                                    mMaterialDialog.dismiss();

                                }

                            });
                    mMaterialDialog.show();
                }

            }

            @Override
            public void onFailure(Call<AllUserDataModel> call, Throwable t) {
                Log.d("ONFail", t + "");
                mMaterialDialog = new MaterialDialog(SyncActivity.this)
                        .setTitle("Error")
                        .setMessage("Your email and password are incorrect!!!")
                        .setPositiveButton("OK", new View.OnClickListener() {

                            @Override

                            public void onClick(View v) {
                                mMaterialDialog.dismiss();

                            }

                        });
                mMaterialDialog.show();

            }

        });

    }

    public void insert_user_data() {
        OnMyanmar_DataBase dataBase = new OnMyanmar_DataBase(SyncActivity.this, pref.getDB_NAME());
        ContentValues values = new ContentValues();

        values.put(dataBase.KEY_USER_NAME, allUserDataModel.getUser_data().getFirstname() + " "
                + allUserDataModel.getUser_data().getMiddlename() + " "
                + allUserDataModel.getUser_data().getLastname());
        values.put(dataBase.KEY_ROLE_ID, allUserDataModel.getUser_data().getRole_id());
        values.put(dataBase.KEY_PASSWORD, allUserDataModel.getUser_data().getPassword());
        values.put(dataBase.KEY_USER_ID, allUserDataModel.getUser_data().getUser_id());
        values.put(dataBase.KEY_UUID, allUserDataModel.getUser_data().getUuid());

        values.put(dataBase.KEY_TOWNSHIP, allUserDataModel.getUser_data().getTownship());
        values.put(dataBase.KEY_NRC_NO, allUserDataModel.getUser_data().getNrc_no());
        values.put(dataBase.KEY_PHONE, allUserDataModel.getUser_data().getPhone());

        values.put(dataBase.KEY_LOGED_IN, "1");

        long a = dataBase.save_user_data_retro(values);

        Log.d("***error save**", a + "");


    }


    public void getMessage() {
        Toast.makeText(SyncActivity.this, username, Toast.LENGTH_SHORT).show();
//        com.example.user.onmyanmar.api.Application.USER_NAME

        Call<AllUserMessageDataModel> call = retrofitHelper.message(username);
        call.enqueue(new Callback<AllUserMessageDataModel>() {
            @Override
            public void onResponse(Call<AllUserMessageDataModel> call, Response<AllUserMessageDataModel> response) {
                if (response.isSuccessful()) {
                    allmessage = response.body();
                    Log.d("Size", allmessage.getMessage().size() + "");
                    if (!allmessage.getMessage().isEmpty()) {
                        getAllMessage();
                    }

                }
            }

            @Override
            public void onFailure(Call<AllUserMessageDataModel> call, Throwable t) {
                Log.d("fail", "onFailure: ");
            }


        });
    }

    public void getAllMessage() {
        for (int i = 0; i < allmessage.getMessage().size(); i++) {
            values.put(KEY_MESSAGE_ID, allmessage.getMessage().get(i).getId());
            values.put(KEY_SUBJECT, allmessage.getMessage().get(i).getSubject());
            values.put(KEY_BODY, allmessage.getMessage().get(i).getBody());
            values.put(KEY_TRIGGER, allmessage.getMessage().get(i).getTrigger());
            values.put(KEY_TIMESTAMP, allmessage.getMessage().get(i).getTimestamp());
            values.put(KEY_SEND_BY, allmessage.getMessage().get(i).getSend_by());
            values.put(KEY_LASTNAME, allmessage.getMessage().get(i).getLastname());
            values.put(KEY_FIRST_NAME, allmessage.getMessage().get(i).getFirstname());
            values.put(KEY_SEND, "0");
            values.put(KEY_SEEN, "0");
            values.put(KEY_DEL, "0");
            Long a = dataBase.save_message_retro(values);
            Log.d("A", a + " ");

        }
    }



}
