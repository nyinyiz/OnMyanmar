package com.example.user.onmyanmar.api;



import com.example.user.onmyanmar.Model.AllUserDataModel;

import com.example.user.onmyanmar.Model.AllUserMessageDataModel;
import com.example.user.onmyanmar.Model.Expense_Sync_Model;
import com.example.user.onmyanmar.Model.IncomeModel;
import com.example.user.onmyanmar.Model.Income_ExpenseModel;
import com.example.user.onmyanmar.Model.Income_Expense_Data_Model;
import com.example.user.onmyanmar.Model.Income_Sync_Model;
import com.example.user.onmyanmar.Model.Sales_Sync_Model;
import com.example.user.onmyanmar.Model.Sync_Sale_Return;


import retrofit2.Call;

import retrofit2.http.Field;

import retrofit2.http.FormUrlEncoded;

import retrofit2.http.GET;

import retrofit2.http.POST;

import retrofit2.http.Query;



/**

 * Created by User on 7/4/2017.

 */



public interface ApiService {

    @FormUrlEncoded
    @POST("mobile/login")
    Call<AllUserDataModel>login(
            @Field("username") String email,
            @Field("password")String password
    );

    @GET("mobile/message_all")
    Call<AllUserMessageDataModel>message(
            @Query("username") String username
    );

    @FormUrlEncoded
    @POST("mobile/income_summary")
    Call<IncomeModel> getIncome(
            @Field("user_id") String user_id
    );

    @FormUrlEncoded
    @POST("mobile/expense_summary")
    Call<IncomeModel> getExpense(
            @Field("user_id") String user_id
    );

    @FormUrlEncoded
    @POST("mobile/income_expense")
    Call<Income_ExpenseModel> getIncomeExpense(
            @Field("user_id") String user_id
    );

    @FormUrlEncoded
    @POST(ApiConstants.income_post)
    Call<Income_Sync_Model> getIncome_Sync(
            @Field("username") String username,
            @Field("data") String data
    );

    @FormUrlEncoded
    @POST(ApiConstants.sale_post)
    Call<Sync_Sale_Return> getSale_Sync(
            @Field("username") String username,
            @Field("data") String data
    );

    @FormUrlEncoded
    @POST(ApiConstants.expense_post)
    Call<Expense_Sync_Model> getExpense_Sync(
            @Field("username") String username,
            @Field("data") String data
    );

}

