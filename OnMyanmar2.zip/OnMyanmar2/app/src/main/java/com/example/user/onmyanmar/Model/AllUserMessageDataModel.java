package com.example.user.onmyanmar.Model;

import java.util.ArrayList;

/**
 * Created by User on 7/4/2017.
 */

public class AllUserMessageDataModel {

    String status;
    ArrayList<UserMessageDataModel> message;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<UserMessageDataModel> getMessage() {
        return message;
    }

    public void setMessage(ArrayList<UserMessageDataModel> message) {
        this.message = message;
    }


}
