package com.example.user.onmyanmar.api;

/**
 * Created by pyaesone on 7/9/17.
 */

public class Application extends android.app.Application {



    static final String BASE_URL="http://192.168.43.13/kyat_manager/api/";
//      static final String BASE_URL="http://192.168.1.11/kyat_manager/api/";
    public  static String USER_NAME;

    public static long CASH_ON_HAND=0;

    public static int CASH_INCOME;

    public static int CASH_EXPENSE;

}

