package com.example.user.onmyanmar.fragement;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.user.onmyanmar.Model.IncomeModel;
import com.example.user.onmyanmar.OnMyanmar_DataBase;
import com.example.user.onmyanmar.PrefManager;
import com.example.user.onmyanmar.R;
import com.example.user.onmyanmar.UpDownActivity;
import com.example.user.onmyanmar.UserLoginActivity;
import com.example.user.onmyanmar.api.Application;
import com.example.user.onmyanmar.api.RetrofitHelper;
import com.github.lzyzsd.circleprogress.DonutProgress;

import java.util.List;

import me.drakeet.materialdialog.MaterialDialog;

/**
 * Created by pyaesone on 7/10/17.
 */

public class SummaryFragment extends Fragment {

    CardView updown,latestAlert;
    TextView income_text,expense_text,alertName,alertbody,alertid;
    ImageView alerticon;
    RecyclerView.LayoutManager RecyclerViewLayoutManager;
    RecyclerView simpleList;
    List<List<String>> AlertList;

    RetrofitHelper retrofitHelper;

    IncomeModel income_amount;

    MaterialDialog mMaterialDialog;
    PrefManager pref;

    OnMyanmar_DataBase dataBase;
    DonutProgress donut_progress;

    TextView now_month;

    private List<List<String>> allIncome_expense;

    long income_total;
    long expense_total;






//    AllUserDataModel allUserDataModel;

    public SummaryFragment(){

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.content_main, container, false);
        updown= (CardView) v.findViewById(R.id.updown);
        latestAlert = (CardView) v.findViewById(R.id.lastetAlert);
        income_text= (TextView) v.findViewById(R.id.income_text);
        expense_text= (TextView) v.findViewById(R.id.expense_text);
        alertName = (TextView) v.findViewById(R.id.alertName);
        alertbody = (TextView) v.findViewById(R.id.alertbody);
        alertid = (TextView) v.findViewById(R.id.alertid);
        alerticon=(ImageView)v.findViewById(R.id.alerticon);

        retrofitHelper=new RetrofitHelper();

        pref=new PrefManager(getContext());

        dataBase = new OnMyanmar_DataBase(getContext(),pref.getDB_NAME());

        allIncome_expense=dataBase.get_all_income_expense();

        latestAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container, new AlertFragment());
                ft.commit();

            }
        });

        Log.d("get all IE size",allIncome_expense.size()+"");
        for (int i=0;i<allIncome_expense.size();i++)
        {

            Log.d("Price",allIncome_expense.get(i).get(5)+"");
            if (allIncome_expense.get(i).get(2).equals("true"))
            {
                expense_total += Integer.parseInt(allIncome_expense.get(i).get(5));

            }else
            {
                income_total += Integer.parseInt(allIncome_expense.get(i).get(5));
            }
        }


        Application.CASH_ON_HAND = income_total - expense_total;


        expense_text.setText(expense_total +" Kyats");
        income_text.setText(income_total +" Kyats");

        updown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                FragmentTransaction ft = getFragmentManager().beginTransaction();
//                ft.replace(R.id.container, new SummaryFragment());
//                ft.commit();
                Intent intent=new Intent(getContext(),UpDownActivity.class);
                startActivity(intent);
            }
        });

        donut_progress= (DonutProgress) v.findViewById(R.id.donut_progress);

        if (income_total == 0)
        {
            income_total = (long) 0.1;
        }

        int percentage= (int) (((income_total - expense_total)/(income_total+0.0000001))*100);

        if (percentage < 0)
        {
            percentage = percentage * (-1);
            donut_progress.setFinishedStrokeColor(getResources().getColor(R.color.colorPrimary));
            donut_progress.setTextColor(getResources().getColor(R.color.colorPrimary));
        }
        donut_progress.setDonut_progress(percentage+"");

        now_month= (TextView) v.findViewById(R.id.now_month);
//        Calendar cal=Calendar.getInstance();
//        SimpleDateFormat month_date = new SimpleDateFormat("MMM");
//        String month_name = month_date.format(cal.getTime());
//        int thisYear = cal.get(Calendar.YEAR);
//        now_month.setText(month_name+" "+thisYear);


//        Log.d(TAG, "# thisYear : " + thisYear);
//        now_month.setText((CharSequence) cal.getTime());
//        now_month.append(" "+thisYear+"");

        AlertList = dataBase.get_latest_message();
        if(AlertList.size()>0)
        {
            alertName.setText(AlertList.get(0).get(3));
            alertbody.setText(AlertList.get(0).get(4));
            alertid.setText(AlertList.get(0).get(0));
            if(AlertList.get(0).get(3).equals("Inactive Expense")||AlertList.get(0).get(3).equals("Inactive Income"))
            {
                alerticon.setImageResource(R.drawable.inactive);
            }
            else if(AlertList.get(0).get(3).equals("Over Budget"))
            {
                alerticon.setImageResource(R.drawable.budget_overflow);
            }
            else if(AlertList.get(0).get(3).equals("Low Sale"))
            {
                alerticon.setImageResource(R.drawable.low_sale);
            }
            else if(AlertList.get(0).get(3).equals("Low Cash"))
            {
                alerticon.setImageResource(R.drawable.low_balance);
            }
            else if(AlertList.get(0).get(3).equals("Stagnant Product"))
            {
                alerticon.setImageResource(R.drawable.product);
            }
            else if(AlertList.get(0).get(3).equals("Upcoming payment"))
            {
                alerticon.setImageResource(R.drawable.income_payment);
            }
            else
            {
                alerticon.setImageResource(R.drawable.alert);
            }


        }


        return v;

    }


}
