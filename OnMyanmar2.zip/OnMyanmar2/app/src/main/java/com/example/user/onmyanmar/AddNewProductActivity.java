package com.example.user.onmyanmar;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.user.onmyanmar.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_NAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_TIMESTAMP;

public class AddNewProductActivity extends AppCompatActivity {

    EditText product_input;
    Button add;
    String product_name;
    int state;
    OnMyanmar_DataBase dataBase;
    ContentValues values;
    PrefManager pref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_product);

        pref = new PrefManager(getApplicationContext());
        dataBase = new OnMyanmar_DataBase(AddNewProductActivity.this, pref.getDB_NAME());
        values = new ContentValues();

        product_input = (EditText) findViewById(R.id.new_product_txt);
        add = (Button) findViewById(R.id.add_new_product);

        state = getIntent().getIntExtra("state",0);
        Log.d("State ",state+"");


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (product_input.getText().toString() != null)
                {
                    product_name = product_input.getText().toString();

                    Log.d("Product name :",product_name);

                    if (state == 0)
                    {
                        insert_Sale();

                    }else
                    {
                        insert_Equipment();
                    }
                    finish();

                }else
                {
                    Toast.makeText(AddNewProductActivity.this, "Please Enter product name", Toast.LENGTH_SHORT).show();

                }

            }
        });

    }
//
//    + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
//
//            + KEY_PRODUCT_TYPE_ID + " TEXT,"
//
//            + KEY_NAME + " TEXT,"
//
//            + KEY_TIMESTAMP + " TEXT)";

    public void insert_Sale() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateTime = dateFormat.format(new Date()); // Find todays date

        values.put(KEY_NAME,product_name);
        values.put(dataBase.KEY_TIMESTAMP,currentDateTime);

        long a = dataBase.save_catago_for_income(values);
        Log.d("Income catago table", a + "");

    }
//
//             + KEY_ID + " INTEGER PRIMARY KEY,"
//
//            + KEY_EQUIPMENT_ID + " TEXT,"
//
//            + KEY_NAME + " TEXT,"
//
//            + KEY_UNIT_PRICE + " TEXT,"
//
//            + KEY_QUANTITY + " TEXT,"
//
//            + KEY_DESCR + " TEXT,"
//
//            + KEY_TIMESTAMP + " TEXT)";

    public void insert_Equipment() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateTime = dateFormat.format(new Date()); // Find todays date

        values.put(KEY_NAME, product_name);
        values.put(KEY_TIMESTAMP,currentDateTime);

        long a = dataBase.save_catago_for_expense(values);
        Log.d("Expence catago table", a + "");

    }
}
