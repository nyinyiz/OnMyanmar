package com.example.user.onmyanmar.Model;

import java.util.ArrayList;

/**
 * Created by User on 7/25/2017.
 */

public class DataModel {

    ArrayList<NewIncomeSyncModel> data;

    public ArrayList<NewIncomeSyncModel> getData() {
        return data;
    }

    public void setData(ArrayList<NewIncomeSyncModel> data) {
        this.data = data;
    }
}
