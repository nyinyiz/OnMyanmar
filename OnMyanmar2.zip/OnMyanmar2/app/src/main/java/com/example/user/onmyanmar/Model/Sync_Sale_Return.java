package com.example.user.onmyanmar.Model;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by User on 7/27/2017.
 */

public class Sync_Sale_Return {
//    "status": "equipments",
//            "result":

    String status;
    ArrayList<Sale_Sync> result;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<Sale_Sync> getResult() {
        return result;
    }

    public void setResult(ArrayList<Sale_Sync> result) {
        this.result = result;
    }
}
