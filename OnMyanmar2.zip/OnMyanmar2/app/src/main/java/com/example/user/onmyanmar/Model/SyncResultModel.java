package com.example.user.onmyanmar.Model;

/**
 * Created by pyaesone on 7/21/17.
 */

public class SyncResultModel {

//    {
//        "user_id": "4",
//            "uuid": "99fb2667-55df-4f23",
//            "sale_id": "107",
//            "amount": "15000",
//            "on_credit": "0",
//            "quantity": "1",
//            "descr": "",
//            "note": "",
//            "submitted_at": "2016-04-28 08:52:07",
//            "status": "income",
//    }

    String user_id;
    String uuid;
    String sale_id;
    String amount;
    String on_credit;
    String quantity;
    String descr;
    String note;
    String submitted_at;
    String status;


}
