package com.example.user.onmyanmar;



import android.content.ContentValues;

import android.content.Context;

import android.database.Cursor;

import android.database.sqlite.SQLiteDatabase;

import android.database.sqlite.SQLiteOpenHelper;

import android.util.Log;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;



public class OnMyanmar_DataBase extends SQLiteOpenHelper {

    //INCOME_EXPENSE

    public static final String KEY_INCOME_EXPENSE_TABLE = "incomeexpense",

            KEY_INCOME = "income",

            KEY_EXPENSE = "expense",

            KEY_PRODUCT_NAME = "product_name",

            KEY_INCOME_EXPENSE_TIMESTAMP = "timestamp",

            KEY_PRODUCT_PRICE = "product_price";

    // USER TABLE

    public static final String KEY_USER_TABLE = "users";

    public static final String KEY_ID = "id";

    public static final String KEY_ROLE_ID = "role_id";

    public static final String KEY_USER_NAME = "username";

    public static final String KEY_LOGED_IN = "loged_in";

    public static final String KEY_PASSWORD = "password";

    public static final String KEY_EMAIL = "email";

    public static final String KEY_FIRST_NAME = "firstname";

    public static final String KEY_MIDDLE_NAME = "middlename";

    public static final String KEY_LASTNAME = "lastname";

    public static final String KEY_TOWNSHIP = "township";

    public static final String KEY_CITY = "city";

    public static final String KEY_STATE = "state";

    public static final String KEY_NRC_NO = "nrc_no";

    public static final String KEY_PHONE = "phone";

    public static final String KEY_BUSINESS_NAME = "business_name";

    public static final String KEY_STATUS = "status";

    public static final String KEY_UPDATED_AT = "updated_at";

    public static final String KEY_UUID = "uuid";

    public static final String KEY_USER_ID = "user_id";

    public static final String KEY_QUANTITY = "quantity";

    public static final String KEY_DESCR = "descr";

    //sync

    public static final String KEY_SUBMITTED_AT = "submitted_at";

    //MESSAGE_TABLE

    public static final String KEY_MESSAGE_TABLE = "messages";

    public static final String KEY_MESSAGE_ID = "message_id";

    public static final String KEY_SUBJECT = "subject";

    public static final String KEY_BODY = "body";

    public static final String KEY_SEND_BY = "send_by";

    public static final String KEY_SEEN = "seen";

    public static final String KEY_TRIGGER = "trigger";

    public static final String KEY_EXPENSE_ID = "expense_id";

    public static final String KEY_DEL = "deleted";

    public static final String KEY_TIMESTAMP = "timestamp";

    public static final String KEY_STARTUP_BUDGET = "startup_budget";

    public static final String KEY_INSTALLATION_FEES = "installation_fees";

    public static final String KEY_STARTING_INVENTROY = "starting_inventory";

    public static final String KEY_OTHER_FEES = "other_fees";

    public static final String KEY_ADVANCED_RENT = "advanced_rent";

    public static final String KEY_LICENSS = "license";

    public static final String KEY_ADVERTISING = "advertising";

    public static final String KEY_OPERATING_CASH = "operating_cash";

    public static final String KEY_START_DATE = "start_date";

    public static final String KEY_EQUIPMENT = "equipment";

    public static final String KEY_EQUIPMENT_ID = "equipment_id";

    public static final String KEY_STARTUP_BUDGET_ID = "startup_budget_id";

    public static final String KEY_SYNC = "sync";

    public static final String KEY_EXPENSES_TABLE = "expenses_table",

            KEY_CATEGORY_ID = "category_id",

            KEY_AMOUNT = "amount",

            KEY_DESCRIPTION = "description",

            KEY_ON_CREDIT = "on_credit",

            KEY_NOTE = "note",

            KEY_SAVE_DATE = "save_date";

    public static final String KEY_INCOME_TABLE = "products",

            KEY_SALE_AMOUNT = "sale_amount",

            KEY_PRODUCT_TYPE_ID = "product_id",

            KEY_UNIT = "no_of_unit",

            KEY_PRICE_PER_ONE = "key_price_per_one",

            KEY_SEND = "send",

            KEY_INCOME_ID = "income_id",

            KEY_EMPLOYEE_ID = "employee_id";

    public static final String KEY_PRODUCT_TYPE_TABLE = "product_types";

    public static final String KEY_NAME = "name";

    public static final String KEY_UNIT_COST = "unit_cost";

    public static final String KEY_UNIT_PRICE = "unit_price";

    //LOANTable

    public static final String KEY_EDITED = "edited";

    //EXPENSE_CATEGORY_TABLE

    public static final String KEY_UPDATED = "updated";

    //EXPENSE_TABLE

    public static final String KEY_DELETED = "deleted";

    //PRODUCT_TABLE

    private static final int DATABASE_VERSION = 1;

    //PRODUCT_TYPE_TABLE

    private static final String DATABASE_NAME = "onmyanmar";

    //MESSAGE SEND

    private static final String KEY_MESSAGE_SEND_TABLE = "message_send",

            KEY_SEND_TO = "send_to",

            KEY_MESSAGE_TO_REPLY = "message_to_reply";

    //EXPENSE_TYPE_TABLE

    private static final String KEY_EXPENSE_TYPE_TABLE = "expense_types";

    private static final String KEY_REPLY_TO = "reply_to";

    //PRODUCT_TEMP_TABLE

    private static final String KEY_BUDGET_ID = "budget_id";

    //CATEGORY_TEMP_TABLE

    private static final String KEY_LOAN_TABLE = "loan",

            KEY_OPENING_BALANCE = "opening_balance",

            KEY_COMPOUND_INTEREST_RATE = "compound_interest",

            KEY_NO_OF_YEAR = "no_of_year",

            KEY_MONTHLY_PAYMENT = "monthly_payment";

    private static final String KEY_EXPENSE_CATEGORY = "expense_category";

    private static final String KEY_PRODUCT_TEMP_TABLE = "temp_product_type",

            KEY_TEMP_PRODUCT_NAME = "temp_name",

            KEY_TEMP_PRODUCT_ID = "temp_id",

            KEY_TEMP_SEND_SERVER = "temp_send";

    private static final String KEY_CATEGORY_TEMP_TABLE = "temp_expense",

            KEY_TEMP_CATEGORY_NAME = "temp_name",

            KEY_TEMP_CATEGORY_ID = "temp_category_id";

    private static final String KEY_PERSONNEL_TABLE = "personnel";

    private static final String KEY_ROLE = "role";

    private static final String KEY_EMPLOYEE_NAME = "employee_name";

    private static final String KEY_WAGES = "wages";

    private static final String KEY_MONTH_STARTING = "month_starting";

    private static final String KEY_MONTH_ENDING = "month_ending";

    private static final String KEY_ACTIVATE = "activate";

    private static final String KEY_TOTAL_INCOME_TABLE = "total_income_table",

            KEY_TOTAL_INCOME = "total_income";

    private static final String KEY_TOTAL_EXPENSES_TABLE = "total_expense_table",

            KEY_TOTAL_EXPENSES = "total_expense";

    //PRODUCT_

//    public OnMyanmar_DataBase(Context context) {

//        super(context, DATABASE_NAME, null, DATABASE_VERSION);

//    }

    public OnMyanmar_DataBase(Context context, String DBName) {

        super(context, DBName, null, DATABASE_VERSION);

    }

    @Override

    public void onCreate(SQLiteDatabase db) {

//        onUpgrade("onmyanmar_db_",1,2);

//        db.execSQL("DROP DATABASE "+"onmyanmar_db_");

        //INCOME_EXPENSE

        String CREATE_INCOME_EXPENSE_TABLE = "CREATE TABLE " + KEY_INCOME_EXPENSE_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_INCOME + " TEXT,"

                + KEY_EXPENSE + " TEXT,"

                + KEY_PRODUCT_NAME + " TEXT,"

                + KEY_INCOME_EXPENSE_TIMESTAMP + " TEXT,"

                + KEY_PRODUCT_PRICE + " TEXT,"

                + KEY_AMOUNT + " TEXT,"

                + KEY_QUANTITY + " TEXT,"

                + KEY_DELETED + " TEXT,"

                + KEY_INCOME_ID + " TEXT,"

                + KEY_EXPENSE_ID + " TEXT)";

        //USER_TABLE

        String CREATE_USER_TABLE = "CREATE TABLE " + KEY_USER_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_ROLE_ID + " TEXT,"

                + KEY_USER_ID + " TEXT,"

                + KEY_UUID + " TEXT,"

                + KEY_LOGED_IN + " TEXT,"

                + KEY_USER_NAME + " TEXT,"

                + KEY_PASSWORD + " TEXT,"

                + KEY_EMAIL + " TEXT,"

                + KEY_FIRST_NAME + " TEXT,"

                + KEY_MIDDLE_NAME + " TEXT,"

                + KEY_LASTNAME + " TEXT,"

                + KEY_STATUS + " TEXT,"

                + KEY_TOWNSHIP + " TEXT,"

                + KEY_CITY + " TEXT,"

                + KEY_STATE + " TEXT,"

                + KEY_NRC_NO + " TEXT,"

                + KEY_PHONE + " TEXT,"

                + KEY_BUSINESS_NAME + " TEXT,"

                + KEY_UPDATED_AT + " TEXT)";

        String CREATE_STARTUP_BUDGET_TABLE = "CREATE TABLE " + KEY_STARTUP_BUDGET + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_STARTUP_BUDGET_ID + " TEXT,"

                + KEY_USER_ID + " TEXT,"

                + KEY_INSTALLATION_FEES + " TEXT,"

                + KEY_STARTING_INVENTROY + " TEXT,"

                + KEY_OTHER_FEES + " TEXT,"

                + KEY_ADVANCED_RENT + " TEXT,"

                + KEY_LICENSS + " TEXT,"

                + KEY_ADVERTISING + " TEXT,"

                + KEY_OPERATING_CASH + " TEXT,"

                + KEY_START_DATE + " TEXT,"

                + KEY_TIMESTAMP + " TEXT)";

        //MESSAGE_TABLE

        String CREATE_MESSAGE_TABLE = "CREATE TABLE " + KEY_MESSAGE_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_REPLY_TO + " TEXT,"

                + KEY_MESSAGE_ID + " TEXT,"

                + KEY_SUBJECT + " TEXT,"

                + KEY_BODY + " TEXT,"

                + KEY_FIRST_NAME + " TEXT,"

                + KEY_LASTNAME + " TEXT,"

                + KEY_TIMESTAMP + " TEXT,"

                + KEY_SEND_BY + " TEXT,"

                + KEY_SEND + " TEXT,"

                + KEY_SEEN + " TEXT,"

                + KEY_TRIGGER + " TEXT,"

                + KEY_DEL + " TEXT)";

        String CREATE_EQUIPMENTS_TABLE = "CREATE TABLE " + KEY_EQUIPMENT + "("

                + KEY_ID + " INTEGER PRIMARY KEY,"

                + KEY_EQUIPMENT_ID + " TEXT,"

                + KEY_NAME + " TEXT,"

                + KEY_UNIT_PRICE + " TEXT,"

                + KEY_QUANTITY + " TEXT,"

                + KEY_DESCR + " TEXT,"

                + KEY_TIMESTAMP + " TEXT)";

        String CREATE_LOAN_TABLE = "CREATE TABLE " + KEY_LOAN_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY,"

                + KEY_OPENING_BALANCE + " TEXT,"

                + KEY_COMPOUND_INTEREST_RATE + " TEXT,"

                + KEY_NO_OF_YEAR + " TEXT,"

                + KEY_MONTHLY_PAYMENT + " TEXT)";

        //SALE_TABLE

        //MONTHLY_BUDGETS

//        CREATE MESSAGE_SEND_TABLE

        String CREATE_MESSAGE_SEND_TABLE = "CREATE TABLE " + KEY_MESSAGE_SEND_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_MESSAGE_TO_REPLY + " TEXT,"

                + KEY_SEND_TO + " TEXT,"

                + KEY_TIMESTAMP + " TEXT,"

                + KEY_BODY + " TEXT,"

                + KEY_SUBJECT + " TEXT)";

//        CREATE EXPENSE_CATEGORY_TABLE

        String CREATE_EXPENSE_CATEGORY_TABLE = "CREATE TABLE " + KEY_EXPENSE_TYPE_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_CATEGORY_ID + " TEXT,"

                + KEY_EXPENSE_CATEGORY + " TEXT,"

                + KEY_TIMESTAMP + "TEXT)";

        String CREATE_EXPENSES_TABLE = "CREATE TABLE " + KEY_EXPENSES_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_SAVE_DATE + " TEXT,"

                + KEY_CATEGORY_ID + " TEXT,"

                + KEY_AMOUNT + " TEXT,"

                + KEY_UNIT + " TEXT,"

                + KEY_PRICE_PER_ONE + " TEXT,"

                + KEY_DESCRIPTION + " TEXT,"

                + KEY_ON_CREDIT + " TEXT,"

                + KEY_NOTE + " TEXT,"

                + KEY_EDITED + " TEXT,"

                + KEY_UPDATED + " TEXT,"

                + KEY_SEND + " TEXT,"

                + KEY_UUID + " TEXT,"

                + KEY_DELETED + " TEXT,"

                + KEY_EXPENSE_ID + " TEXT,"

                + KEY_SYNC + " TEXT,"

                + KEY_SUBMITTED_AT + " TEXT )";

        String CREATE_PRODUCT_TABLE = "CREATE TABLE " + KEY_INCOME_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_SAVE_DATE + " DATE,"

                + KEY_PRODUCT_TYPE_ID + " TEXT,"

                + KEY_SALE_AMOUNT + " TEXT,"

                + KEY_UNIT + " INTEGER,"

                + KEY_PRICE_PER_ONE + " TEXT,"

                + KEY_ON_CREDIT + " TEXT,"

                + KEY_DESCRIPTION + " TEXT,"

                + KEY_NOTE + " TEXT,"

                + KEY_SEND + " TEXT,"

                + KEY_UUID + " TEXT,"

                + KEY_EDITED + " TEXT,"

                + KEY_DELETED + " TEXT,"

                + KEY_INCOME_ID + " TEXT,"

                + KEY_SYNC + " TEXT,"

                + KEY_SUBMITTED_AT + " TEXT )";

        String CREATE_PRODUCT_TYPE_TABLE = "CREATE TABLE " + KEY_PRODUCT_TYPE_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_PRODUCT_TYPE_ID + " TEXT,"

                + KEY_NAME + " TEXT,"

                + KEY_SYNC + " TEXT,"

                + KEY_TIMESTAMP + " TEXT)";

        String CREATE_PERSONNEL_TABLE = "CREATE TABLE " + KEY_PERSONNEL_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_EMPLOYEE_NAME + " TEXT,"

                + KEY_ROLE + " TEXT,"

                + KEY_WAGES + " TEXT,"

                + KEY_MONTH_STARTING + " TEXT,"

                + KEY_MONTH_ENDING + " TEXT,"

                + KEY_SAVE_DATE + " DATE,"

                + KEY_ACTIVATE + " TEXT,"

                + KEY_EDITED + " TEXT,"

                + KEY_UPDATED + " TEXT,"

                + KEY_SEND + " TEXT,"

                + KEY_UUID + " TEXT,"

                + KEY_EMPLOYEE_ID + " TEXT,"

                + KEY_TIMESTAMP + "DATETIME DEFAULT CURRENT_TIMESTAMP)";

        String CREATE_PRODUCT_TEMP_TABLE = "CREATE TABLE " + KEY_PRODUCT_TEMP_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_TEMP_PRODUCT_NAME + " TEXT,"

                + KEY_TEMP_PRODUCT_ID + " TEXT,"

                + KEY_TEMP_SEND_SERVER + " TEXT,"

                + KEY_TIMESTAMP + "TEXT)";

        String CREATE_CATEGORY_TEMP_TABLE = "CREATE TABLE " + KEY_CATEGORY_TEMP_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_TEMP_CATEGORY_NAME + " TEXT,"

                + KEY_TEMP_CATEGORY_ID + " TEXT,"

                + KEY_TEMP_SEND_SERVER + " TEXT,"

                + KEY_TIMESTAMP + "TEXT)";

        String CREATE_TOTAL_INCOME_TABLE = "CREATE TABLE " + KEY_TOTAL_INCOME_TABLE + "("

                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"

                + KEY_TOTAL_INCOME + " INTEGER)";

        //CREATE_INCOME_EXPENSE

        db.execSQL(CREATE_INCOME_EXPENSE_TABLE);

        //CREATE_USER_TABLE

        db.execSQL(CREATE_USER_TABLE);

        //CREATE_PRODUCT_TABLE

        db.execSQL(CREATE_PRODUCT_TABLE);

        //CREATE_PRODUCT_TYPE

        db.execSQL(CREATE_PRODUCT_TYPE_TABLE);

        //CREATE_MESSAGE_TABLE

        db.execSQL(CREATE_MESSAGE_TABLE);

        //CREATE_STARTUP_BUDGET_TABLE

        db.execSQL(CREATE_STARTUP_BUDGET_TABLE);

        //CREATE_EQUIPMENTS_TABLE

        db.execSQL(CREATE_EQUIPMENTS_TABLE);

        //CREATE_MESSAGE_SEND_TABLE

        db.execSQL(CREATE_MESSAGE_SEND_TABLE);

        //CREATE_EXPENSE_CATEGORY_TABLE

        db.execSQL(CREATE_EXPENSE_CATEGORY_TABLE);

        //CREATE_EXPENSES_TABLE

        db.execSQL(CREATE_EXPENSES_TABLE);

        //CREATE_PERSONNEL_TABLE

        db.execSQL(CREATE_PERSONNEL_TABLE);

        //CREATE_TEMP_PRODUCT_TABLE

        db.execSQL(CREATE_PRODUCT_TEMP_TABLE);

        //CREATE_CATEGORY_TEMP_TABLE

        db.execSQL(CREATE_CATEGORY_TEMP_TABLE);

        //CREATE_TOTAL_INCOME_TABLE

        db.execSQL(CREATE_TOTAL_INCOME_TABLE);

        //CREATE_TOTAL_INCOME_TABLE

        db.execSQL(CREATE_LOAN_TABLE);

    }

    @Override

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //UPGRATE INCOME_EXPENSE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_INCOME_EXPENSE_TABLE);

        //UPGRATE USER_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_USER_TABLE);

        //UPGRATE PRODUCT_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_INCOME_TABLE);

        //UPGRATE PRODUCT_TYPE_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_PRODUCT_TYPE_TABLE);

        //UPGRATE MESSAGE_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_MESSAGE_TABLE);

        //UPGRATE MESSAGE_SEND_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_MESSAGE_SEND_TABLE);

        //UPGRATE EXPENSE_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_EXPENSES_TABLE);

        //UPGRATE EXPENSE_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_EXPENSE_TYPE_TABLE);

        //UPGRATE PERSONNEL TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_PERSONNEL_TABLE);

        //UPGRATE PREODUCT_TEMP_TABEL

        db.execSQL("DROP TABLE IF EXISTS " + KEY_PRODUCT_TYPE_TABLE);

        //UPGRATE CATEGORY_TEMP_TABEL

        db.execSQL("DROP TABLE IF EXISTS " + KEY_CATEGORY_TEMP_TABLE);

        //UPGRATE TOTAL_INCOME_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_TOTAL_INCOME_TABLE);

        //UPGRATE TOTAL_EXPENSE_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_TOTAL_EXPENSES_TABLE);

        //UPGRATE TOTAL_EXPENSE_TABLE

        db.execSQL("DROP TABLE IF EXISTS " + KEY_PRODUCT_TEMP_TABLE);

        db.execSQL("DROP TABLE IF EXISTS " + KEY_LOAN_TABLE);

//        db.execSQL("DROP DATABASE"+DATABASE_NAME);

        onCreate(db);

    }

    public void update_alert_del(Integer pos) {

        SQLiteDatabase db = this.getReadableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_DEL, "1");

        db.update(KEY_MESSAGE_TABLE, values, KEY_ID + "= " + pos, null);

    }

    public void update_alert_del_all() {

        SQLiteDatabase db = this.getReadableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_DEL, "1");

        db.update(KEY_MESSAGE_TABLE, values, KEY_DEL + "= 0", null);

    }

    public void update_income_expense(ContentValues values, Integer id) {

        Log.d("Income_expense_id", id + "");

        SQLiteDatabase db = this.getReadableDatabase();

        int done = db.update(KEY_INCOME_EXPENSE_TABLE, values, KEY_ID + " = " + id, null);

        Log.d("Updated", done + "");

    }

    public void update_income(ContentValues values, Integer id) {

        Log.d("Income_id", id + "");

        SQLiteDatabase db = this.getReadableDatabase();

        int done = db.update(KEY_INCOME_TABLE, values, KEY_ID + " = " + id, null);

        Log.d("Income Updated", done + "");

    }

    public void update_income_by_uuid(ContentValues values,String uuid)
    {
        Log.d("Income_uuid", uuid + "");

        SQLiteDatabase db = this.getReadableDatabase();

        int done = db.update(KEY_INCOME_TABLE, values, KEY_ID + " = " + uuid + " ", null);

        Log.d("Income Updated", done + "");

    }

    public void update_sale_by_id(ContentValues values,String id)
    {
        Log.d("Sale_id", id + "");

        SQLiteDatabase db = this.getReadableDatabase();

        int done = db.update(KEY_PRODUCT_TYPE_TABLE, values, KEY_PRODUCT_TYPE_ID + " = " + id + "", null);

        Log.d("Sale Updated", done + "");
    }

    public void update_expense_by_uuid(ContentValues values,String uuid)
    {
        Log.d("Expense_uuid", uuid + "");

        SQLiteDatabase db = this.getReadableDatabase();

        int done = db.update(KEY_EXPENSES_TABLE, values, KEY_ID + " = " + uuid + " ", null);

        Log.d("Income Updated", done + "");
    }


    public void update_expense(ContentValues values, Integer id) {

        Log.d("expense_id", id + "");

        SQLiteDatabase db = this.getReadableDatabase();

        int done = db.update(KEY_EXPENSES_TABLE, values, KEY_ID + " = " + id, null);

        Log.d("Expense Updated", done + "");

    }

    public long save_message_retro(ContentValues values) {

        SQLiteDatabase db = this.getReadableDatabase();

        long a = db.insert(KEY_MESSAGE_TABLE, null, values);

        return a;

    }

    public long save_income(ContentValues values) {

        SQLiteDatabase db = this.getWritableDatabase();

        long a = db.insert(KEY_INCOME_TABLE, null, values);

        return a;

    }

    public long save_catago_for_income(ContentValues values)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        long a = db.insert(KEY_PRODUCT_TYPE_TABLE, null, values);

        return a;
    }

    public long save_catago_for_expense(ContentValues values)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        long a = db.insert(KEY_EQUIPMENT, null, values);

        return a;
    }


    public long save_user_data_retro(ContentValues values) {

        SQLiteDatabase db = this.getWritableDatabase();

        long a = db.insert(KEY_USER_TABLE, null, values);

        return a;

    }

    public long save_sale_data_retro(ContentValues values)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        long a = db.insert(KEY_PRODUCT_TYPE_TABLE, null, values);

        return a;
    }

    public List<List<String>> get_sale_data()
    {

        SQLiteDatabase db = this.getReadableDatabase();

        List<List<String>> result = new ArrayList<List<String>>();

        String selectQuery = "SELECT * FROM " + KEY_PRODUCT_TYPE_TABLE;

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

//            temp.add(cursor.getString(0));

            temp.add(cursor.getString(2));

//            temp.add(cursor.getString(2));

            result.add(temp);

            Log.d("****ResultOn**", result + "");

        }

        return result;
    }


    //SAVE_INCOME_EXPENSE

    public long save_income_expense(ContentValues values) {

        SQLiteDatabase db = this.getWritableDatabase();

        long a = db.insert(KEY_INCOME_EXPENSE_TABLE, null, values);

        return a;

    }

    //DEL_INCOME_EXPENSE

    public void update_income_expense_del(Integer pos, String type, String IEid) {

        Log.d("POS in update", pos.toString());

        Log.d("type in update", type);

        Log.d("IEid in update", IEid);

        Integer pos1 = pos - 1;

        SQLiteDatabase db = this.getReadableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_DELETED, "1");

        db.update(KEY_INCOME_EXPENSE_TABLE, values, KEY_ID + "= " + pos, null);

//        Log.d("Ie id",IEid+"");

        if (type.equals("true")) {

            int a = db.update(KEY_EXPENSES_TABLE, values, KEY_ID + "= '" + IEid + "'", null);

            Log.d("Expense deleted", a + "");

        } else {

            int a = db.update(KEY_INCOME_TABLE, values, KEY_ID + "= '" + IEid + "'", null);

            Log.d("Income deleted", a + "");

        }

    }

    public List<List<String>> get_latest_message() {

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + KEY_MESSAGE_TABLE + " WHERE " + KEY_DEL + " = '0'"

                + " ORDER BY " + KEY_TIMESTAMP + " DESC ";//+ " LIMIT 10" ;

        List<List<String>> result = new ArrayList<List<String>>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(String.valueOf(cursor.getInt(0)));

            temp.add(cursor.getString(1));

            temp.add(cursor.getString(2));

            temp.add(cursor.getString(3));

            temp.add(cursor.getString(4));

            temp.add(cursor.getString(5));

            temp.add(cursor.getString(7));

            temp.add(cursor.getString(10));

            temp.add(cursor.getString(8));

            Log.d("***message_result***", temp.toString());

            result.add(temp);

        }

        return result;

    }

    public List<List<String>> get_all_income_expense() {

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + KEY_INCOME_EXPENSE_TABLE + " WHERE " + KEY_DELETED + "= '0' ORDER BY " + KEY_ID + " DESC ";// + " LIMIT 10" ;

        List<List<String>> result = new ArrayList<List<String>>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(String.valueOf(cursor.getInt(0)));

            temp.add(cursor.getString(1));

            temp.add(cursor.getString(2));

            temp.add(cursor.getString(3));

            temp.add(cursor.getString(4));

            temp.add(cursor.getString(5));

            temp.add(cursor.getString(6));

            temp.add(cursor.getString(7));

            temp.add(cursor.getString(8));

            temp.add(cursor.getString(9));

            temp.add(cursor.getString(10));

            Log.d("message_Income_expense", temp.toString());

            result.add(temp);

        }

        return result;

    }

    public List<List<String>> get_income_by_id(int id) {

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + KEY_INCOME_TABLE + " WHERE " + KEY_ID + " = " + id;

        List<List<String>> result = new ArrayList<List<String>>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(cursor.getString(4));

            temp.add(cursor.getString(5));

            Log.d("***message_result***", temp.toString());

            result.add(temp);

        }

        return result;

    }

    public List<List<String>> get_daily_income(String date) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = dateFormat.parse(date);
        date1 = new Date(date1.getTime() - 1 * 24 * 3600 * 1000l);
        String Pdate=dateFormat.format(date1);
        SQLiteDatabase db = this.getReadableDatabase();
//        String selectQuery = "SELECT * FROM " + KEY_INCOME_TABLE + " WHERE " + KEY_SAVE_DATE + " >= '2017-07-25' AND "+  KEY_SAVE_DATE + " < '2017-07-26'";
        Log.d("Date1 : ",Pdate+"");
        Log.d("Date : ",date+"");
//        String selectQuery = "SELECT * FROM " + KEY_INCOME_TABLE;
        String selectQuery = "SELECT * FROM " + KEY_INCOME_TABLE + " WHERE " + KEY_SAVE_DATE + " >= \'"+Pdate+"\' AND "+  KEY_SAVE_DATE + " < \'"+date+"\'"
                +" AND "+KEY_DELETED+" ='0'";
        List<List<String>> result = new ArrayList<List<String>>(); //"+date+"  //'2017-07-25'

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(cursor.getString(3));
            temp.add(cursor.getString(1));
            Log.d("***mdateI_result***", temp.toString());

            result.add(temp);

        }

        return result;

    }

    public List<List<String>> get_daily_expense(String date) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = dateFormat.parse(date);
        date1 = new Date(date1.getTime() - 1 * 24 * 3600 * 1000l);
        String Pdate=dateFormat.format(date1);
        SQLiteDatabase db = this.getReadableDatabase();
//        Log.d("Current Date:",date);Log.d("Previous Date:",dateFormat.format(date1));
        String selectQuery = "SELECT * FROM " + KEY_EXPENSES_TABLE + " WHERE " + KEY_SAVE_DATE + " >= \'"+Pdate+"\' AND "+  KEY_SAVE_DATE + " < \'"+date+"\'"
                +" AND "+KEY_DELETED+" ='0'";
        List<List<String>> result = new ArrayList<List<String>>();
        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(cursor.getString(3));

            Log.d("***mdateE_result***", temp.toString());

            result.add(temp);

        }

        return result;

    }

    public List<List<String>> get_expense_by_id(int id) {

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + KEY_EXPENSES_TABLE + " WHERE " + KEY_ID + " = " + id;

        List<List<String>> result = new ArrayList<List<String>>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(cursor.getString(4));

            temp.add(cursor.getString(5));

            Log.d("***message_result***", temp.toString());

            result.add(temp);

        }

        return result;

    }

    public List<List<String>> get_income_id() {

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + KEY_INCOME_TABLE + " ORDER BY " + KEY_ID + " DESC ";

        List<List<String>> result = new ArrayList<List<String>>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(String.valueOf(cursor.getInt(0)));

            Log.d("***message_result***", temp.toString());

            result.add(temp);

        }

        return result;

    }

    //    public List<List<String>> get_expense_id() {

//        SQLiteDatabase db = this.getReadableDatabase();

//

//        String selectQuery = "SELECT * FROM " + KEY_EXPENSES_TABLE + " ORDER BY " + KEY_ID + " DESC ";

//

//

//        List<List<String>> result = new ArrayList<List<String>>();

//

//        Cursor cursor = db.rawQuery(selectQuery, null);

//

//        while (cursor.moveToNext()) {

//

//

//            List<String> temp = new ArrayList<String>();

//

//

//            temp.add(String.valueOf(cursor.getInt(0)));

//

//            Log.d("***message_result***", temp.toString());

//

//            result.add(temp);

//

//        }

//

//        return result;

//

//    }

    public List<String> get_expense_id() {

        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM " + KEY_EXPENSES_TABLE + " ORDER BY " + KEY_ID + " DESC ";

        List<String> temp = new ArrayList<String>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            temp.add(String.valueOf(cursor.getInt(0)));

            Log.d("***message_result***", temp.toString());

        }

        return temp;

    }

    public long saved_startup_budget_retro(ContentValues values) {

        SQLiteDatabase db = this.getReadableDatabase();

        long a = db.insert(KEY_STARTUP_BUDGET, null, values);

        return a;

    }

    public long saved_equipment_retro(ContentValues values) {

        SQLiteDatabase db = this.getReadableDatabase();

        long a = db.insert(KEY_EQUIPMENT, null, values);

        return a;

    }

    public List<List<String>> get_equipment() {

        SQLiteDatabase db = this.getReadableDatabase();

        List<List<String>> result = new ArrayList<List<String>>();

        String selectQuery = "SELECT * FROM " + KEY_EQUIPMENT;

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(cursor.getString(2));

//            temp.add(cursor.getString(4));

            result.add(temp);

            Log.d("****ResultOn**", result + "");

        }

        return result;

    }

    public long save_expense(ContentValues values) {

        SQLiteDatabase db = this.getReadableDatabase();

        long a = db.insert(KEY_EXPENSES_TABLE, null, values);

        return a;

    }

    public long insert_expenese(ContentValues values) {

        SQLiteDatabase db = this.getReadableDatabase();

        long a = db.insert(KEY_EXPENSES_TABLE, null, values);

        return a;

    }

    public List<List<String>> get_sales_sync()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + KEY_PRODUCT_TYPE_TABLE + " WHERE " + KEY_SYNC + " = "+ 0 +"";

        List<List<String>> result = new ArrayList<List<String>>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(cursor.getString(0));
            temp.add(cursor.getString(2));
            temp.add(cursor.getString(3));

            Log.d("***msg_sale_result***", temp.toString());
            result.add(temp);

        }

        return result;
    }
    public List<List<String>> get_income_sync() {

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + KEY_INCOME_TABLE + " WHERE " + KEY_SYNC + " = "+ 0 +"";

//        String userQuery = "SELECT  FROM " + KEY_USER_TABLE + " WHERE " + KEY_SYNC + " = 0";
        List<List<String>> result = new ArrayList<List<String>>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(cursor.getString(0));
            temp.add(cursor.getString(2));
            temp.add(cursor.getString(5));
            temp.add(cursor.getString(4));
            temp.add(cursor.getString(7));
            temp.add(cursor.getString(8));
            temp.add(cursor.getString(15));

            temp.add(cursor.getString(14));
            Log.d("***msg_income_result***", temp.toString());
            result.add(temp);

        }

        return result;

    }

    public List<List<String>> get_expense_sync()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + KEY_EXPENSES_TABLE + " WHERE " + KEY_SYNC + " = "+ 0 +"";

//        String userQuery = "SELECT  FROM " + KEY_USER_TABLE + " WHERE " + KEY_SYNC + " = 0";
        List<List<String>> result = new ArrayList<List<String>>();

        Cursor cursor = db.rawQuery(selectQuery, null);

        while (cursor.moveToNext()) {

            List<String> temp = new ArrayList<String>();

            temp.add(cursor.getString(0));
            temp.add(cursor.getString(2));
            temp.add(cursor.getString(3));
            temp.add(cursor.getString(6));
            temp.add(cursor.getString(8));
            temp.add(cursor.getString(16));
            temp.add(cursor.getString(15));

            temp.add(cursor.getString(14));
            Log.d("***msg_income_result***", temp.toString());
            result.add(temp);

        }

        return  result;
    }

}