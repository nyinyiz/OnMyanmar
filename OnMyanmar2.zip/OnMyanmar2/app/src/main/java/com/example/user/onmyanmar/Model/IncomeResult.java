package com.example.user.onmyanmar.Model;

/**
 * Created by User on 7/26/2017.
 */

public class IncomeResult {
//    "uuid": "cf5d5f90-0979-4836-ad98-7456d05800b5",
////            "id": 118,
////            "status": "true"

    String uuid;
    String id;
    String status;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
