package com.example.user.onmyanmar;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.codetroopers.betterpickers.calendardatepicker.CalendarDatePickerDialogFragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import retrofit2.Call;

public class AddIncome_ExpenseActivity extends AppCompatActivity
        implements CalendarDatePickerDialogFragment.OnDateSetListener {

    EditText income_edit_date,income_edit_no_unit,
            income_edit_amount,mProductList;
    String Current_date;
    private static final String FRAG_TAG_DATE_PICKER = "fragment_date_picker_name";
    OnMyanmar_DataBase db;
  //  public List<String> mProductEntries;

    public ArrayList<String> mProductEntries;
    PrefManager pref;

    ArrayAdapter<String> arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_income__expense);
//        db = new OnMyanmar_DataBase(this,pref.getDB_NAME());
        mProductEntries=new ArrayList<String>();

        income_edit_date = (EditText)findViewById(R.id.inc_showMyDate);
        mProductList = (EditText) findViewById(R.id.inc_product);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Current_date= sdf.format(new Date());
        income_edit_date.setText(Current_date);


//        mProductEntries =db.get_all_Product();
//        List<String>temp =  db.get_all_temp_product();
//        for (int k =0;k<temp.size();k++)
//        {
//            mProductEntries.add(temp.get(k));
//        }


        income_edit_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calender();

            }
        });

        mProductList.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                ShowProductType();
            }
        });
    }

    public void Calender()
    {
        CalendarDatePickerDialogFragment cdp = new CalendarDatePickerDialogFragment()
                .setOnDateSetListener((CalendarDatePickerDialogFragment.OnDateSetListener) AddIncome_ExpenseActivity.this)
                .setFirstDayOfWeek(Calendar.SUNDAY);
        cdp.show(getSupportFragmentManager(), FRAG_TAG_DATE_PICKER);
    }

    @Override
    public void onDateSet(CalendarDatePickerDialogFragment dialog, int year, int monthOfYear, int dayOfMonth) {
        income_edit_date.setText(getString(R.string.calendar_date_picker_result_values, year, monthOfYear, dayOfMonth));

    }

    private void ShowProductType()
    {
        LayoutInflater Li = LayoutInflater.from(AddIncome_ExpenseActivity.this);
        View promptsView = Li.inflate(R.layout.listview, null);

        mProductEntries.add("Add New Category");
        mProductEntries.add("Nyi Nyi Zaw");
        mProductEntries.add("Khant Si Thu");

        arrayAdapter = new ArrayAdapter<String>(AddIncome_ExpenseActivity.this,android.R.layout.simple_list_item_1,mProductEntries);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(AddIncome_ExpenseActivity.this);
        alertDialogBuilder.setView(promptsView);
        final EditText userInput = (EditText) promptsView.findViewById(R.id.inc_product_input);
//        final ListView listView = (ListView) promptsView.findViewById(R.id.List);
        final ArrayList<String> arrayList = new ArrayList<String>();

        // Creating a button - Add New Product
        Button btnNewProduct = new Button(this);
        btnNewProduct.setText("ကုန္ပစၥည္း အသစ္ထည္႔မည္");
        btnNewProduct.setTextColor(getResources().getColor(R.color.white));
        btnNewProduct.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

//        listView.addFooterView(btnNewProduct);
//
//        listView.setAdapter(arrayAdapter);


        btnNewProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//
//                Intent i = new Intent(AddIncome_ExpenseActivity.this,AddNewProductActivity.class);
//                startActivity(i);

            }
        });
        userInput.addTextChangedListener(new TextWatcher() {
            String searchString = userInput.getText().toString().toLowerCase();

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                arrayAdapter.getFilter().filter(charSequence);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
//        listView.setAdapter(arrayAdapter);

//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                String select = arrayAdapter.getItem(i);
//                userInput.setText(select);
//            }
//        });
        alertDialogBuilder.setPositiveButton(R.string.ok_myn, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                mProductList.setText(userInput.getText().toString());

            }
        });
        alertDialogBuilder.setNegativeButton(R.string.cancel_myn, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });

        AlertDialog dialog = alertDialogBuilder.create();
        dialog.show();
    }
}
