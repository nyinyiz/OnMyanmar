package com.example.user.onmyanmar.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.user.onmyanmar.PrefManager;
import com.example.user.onmyanmar.R;

import java.util.List;


/**
 * Created by User on 6/30/2017.
 */


public class RecyclerViewAdapterforequipment extends RecyclerView.Adapter<RecyclerViewAdapterforequipment.ViewHolder> {

    Context context;
    ImageView image;


    TextView iname2;

    int upordown[];
    int logos[];
    String imagename[];
    String imagename2[];

    String price[];

    int position;

    View view1;

    PrefManager pref;

    private List<List<String>> allequip;
    TextView equipment;

    public RecyclerViewAdapterforequipment(Context applicationContext, List<List<String>> equip) {

        this.context = applicationContext;

        this.allequip = equip;


    }


    @Override

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        view1 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.single_equipment, viewGroup, false);
        return new ViewHolder(view1);


    }


    @Override

    public void onBindViewHolder(ViewHolder holder, int position) {
        this.position = position;

        Log.d("Total Size", allequip.size() + "");
        Log.d("Equipment name", allequip.get(position).size()+ " ");
        holder.equipment.setText(allequip.get(position).get(0));

    }


    @Override

    public int getItemCount() {

        return allequip.size();

    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        //        TextView SubjectTextView;
        TextView equipment;

        public ViewHolder(View view) {
            super(view);
            equipment = (TextView) view.findViewById(R.id.equipment);


        }

    }

}

