package com.example.user.onmyanmar;


import android.app.DatePickerDialog;

import android.content.ContentValues;

import android.content.DialogInterface;

import android.content.Intent;

import android.support.v7.app.ActionBar;

import android.support.v7.app.AlertDialog;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.text.Editable;

import android.text.TextWatcher;

import android.util.Log;

import android.view.LayoutInflater;

import android.view.View;

import android.widget.AdapterView;

import android.widget.ArrayAdapter;

import android.widget.Button;

import android.widget.DatePicker;

import android.widget.EditText;

import android.widget.ImageButton;

import android.widget.LinearLayout;

import android.widget.ListView;

import android.widget.TextView;

import android.widget.Toast;


import com.codetroopers.betterpickers.calendardatepicker.CalendarDatePickerDialogFragment;


import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.Calendar;

import java.util.Date;

import java.util.List;
import java.util.UUID;

import me.drakeet.materialdialog.MaterialDialog;


public class AddnewCatagoActivity extends AppCompatActivity
        implements CalendarDatePickerDialogFragment.OnDateSetListener {

    String catago_position;

    public String temp_count, temp_input;

    MaterialDialog mMaterialDialog;
    private int textsize = 100;

    int state ;

    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, done, bdot;

    DatePickerDialog datePickerDialog;

    int count;
    ArrayList<String> mylist = new ArrayList<String>();

    String buffer;

    int nCount;

    ImageButton back;

    TextView EditTextResult;

    TextView date;

    private static final String FRAG_TAG_DATE_PICKER = "fragment_date_picker_name";

    String Current_date;


    public ArrayList<String> mProductEntries;

    PrefManager pref;


    ArrayAdapter<String> arrayAdapter;

    TextView mProductList;


    String catago;

    LinearLayout part1;

    public ActionBar actionBar;


    TextView number;


    OnMyanmar_DataBase dataBase;


    EditText userInput;


    List<List<String>> allcatago_equipment;

    ContentValues values, values_expense, value_income;


    EditText userInput_unit;


    int categro_id;


    int total_price;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addnew_catago);
        actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        pref = new PrefManager(getApplicationContext());
        part1 = (LinearLayout) findViewById(R.id.part1);
        catago = getIntent().getStringExtra("catago");
        dataBase = new OnMyanmar_DataBase(AddnewCatagoActivity.this, pref.getDB_NAME());
        values = new ContentValues();
        values_expense = new ContentValues();
        value_income = new ContentValues();
        date = (TextView) findViewById(R.id.date);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Current_date = sdf.format(new Date());

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateTime = dateFormat.format(new Date()); // Find todays date

        date.setText(currentDateTime);

        mProductEntries = new ArrayList<String>();
        EditTextResult = (TextView) findViewById(R.id.editText);
        mProductList = (TextView) findViewById(R.id.inc_product);
        number = (TextView) findViewById(R.id.number);
        EditTextResult.getBackground().clearColorFilter();
        b1 = (Button) findViewById(R.id.btn1);
        b2 = (Button) findViewById(R.id.btn2);
        b3 = (Button) findViewById(R.id.btn3);
        b4 = (Button) findViewById(R.id.btn4);
        b5 = (Button) findViewById(R.id.btn5);
        b6 = (Button) findViewById(R.id.btn6);
        b7 = (Button) findViewById(R.id.btn7);
        b8 = (Button) findViewById(R.id.btn8);
        b9 = (Button) findViewById(R.id.btn9);
        b0 = (Button) findViewById(R.id.btn0);
        done = (Button) findViewById(R.id.btnDone);
        back = (ImageButton) findViewById(R.id.btnback);
        bdot = (Button) findViewById(R.id.btndot);
        if (catago.toString().equals("up")) {
            part1.setBackgroundColor(getResources().getColor(R.color.green));
            getSupportActionBar().setTitle(R.string.income);
            values.put(dataBase.KEY_INCOME, true + "");
            values.put(dataBase.KEY_EXPENSE, false + "");

            state = 0;
            refresh_income_catago();


        } else {
            part1.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            getSupportActionBar().setTitle(R.string.expense);
            values.put(dataBase.KEY_INCOME, false + "");
            values.put(dataBase.KEY_EXPENSE, true + "");

            state = 1;
            refresh_expense_catago();


        }
        date.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Calender();

            }

        });
        dataBase = new OnMyanmar_DataBase(AddnewCatagoActivity.this, pref.getDB_NAME());

        for (int i = 0; i < allcatago_equipment.size(); i++) {
            mProductEntries.add(allcatago_equipment.get(i).get(0));

        }

        mProductList.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                ShowProductType();

            }

        });
        number.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ShownumberType();

            }

        });
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("1");
                AddStack("1");

            }

        });
        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("2");
                AddStack("2");

            }

        });
        b3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("3");
                AddStack("3");

            }

        });
        b4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("4");
                AddStack("4");

            }

        });
        b5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("5");
                AddStack("5");

            }

        });
        b6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("6");
                AddStack("6");

            }

        });
        b7.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("7");
                AddStack("7");

            }

        });
        b8.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("8");
                AddStack("8");

            }

        });
        b9.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("9");
                AddStack("9");

            }

        });
        b0.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append("0");
                AddStack("0");

            }

        });
        back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                SubStack();

            }

        });
        bdot.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                EditTextResult.append(".");
                AddStack(".");

            }

        });

        done.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (number.getText().toString() == getResources().getString(R.string.unit_myn))
                {
                    count = 1;
                }else
                {
                    count = Integer.parseInt(userInput_unit.getText().toString());
                }
                String user_price = EditTextResult.getText().toString();
                String user_choice = mProductList.getText().toString();
                if (user_price.isEmpty() || user_choice == getResources().getString(R.string.product_myn)) {
                    mMaterialDialog = new MaterialDialog(AddnewCatagoActivity.this)
                            .setTitle("Sorry")
                            .setMessage("Please fill exactly!!!")
                            .setPositiveButton("OK", new View.OnClickListener() {

                                @Override
                                public void onClick(View v) {
                                    mMaterialDialog.dismiss();

                                }

                            });
                    mMaterialDialog.show();

                }else {

                    total_price = count * Integer.parseInt(EditTextResult.getText().toString());
                    temp_count = String.valueOf(count);
                    temp_input = EditTextResult.getText().toString();
                    AlertDialog alertDialog = new AlertDialog.Builder(AddnewCatagoActivity.this).create();
                    alertDialog.setTitle("Your Values");
                    alertDialog.setMessage(date.getText().toString() + "\n" + EditTextResult.getText().toString() + "\n" +
                            userInput.getText().toString());
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(AddnewCatagoActivity.this, UpDownActivity.class);
                                    startActivity(intent);
                                    finish();
                                    dialog.dismiss();

                                }

                            });
                    alertDialog.show();
                    if (catago.toString().equals("up")) {
                        insert_income();
                        String lastest_income_id = dataBase.get_income_id().get(0).get(0);
                        insert_income_expense(lastest_income_id, "up");

                    } else {
                        insert_expense();
                        String lastest_expense_id = dataBase.get_expense_id().get(0);
                        insert_income_expense(lastest_expense_id, "down");

                    }
                }

            }

        });


    }

    public void refresh_income_catago()
    {
        allcatago_equipment = dataBase.get_sale_data();
    }
    public void refresh_expense_catago()
    {
        allcatago_equipment = dataBase.get_equipment();
    }

    @Override
    protected void onResume() {
        super.onResume();

        refresh_expense_catago();
        refresh_income_catago();
    }

    public void AddStack(String i) {
        if (EditTextResult.length() >= 5) {
            EditTextResult.setTextSize(textsize -= 5);

        }
        int c = 0;
        nCount = mylist.size();
        mylist.add(i);
        nCount = mylist.size();
        buffer = "";
        while (nCount > 0) {
            buffer += String.valueOf(mylist.get(c));
            c++;
            nCount--;

        }
//        Toast.makeText(this, buffer + "", Toast.LENGTH_SHORT).show();

    }

    public void SubStack() {
        if (EditTextResult.length() < 5) {
            EditTextResult.setTextSize(100);

        }
        int c = 0;
        nCount = mylist.size();
        if (nCount != 0)
            mylist.remove(nCount - 1);
        buffer = "";
        while (nCount > 1) {
            buffer += String.valueOf(mylist.get(c));
            c++;
            nCount--;

        }
//        Toast.makeText(this, mylist + "", Toast.LENGTH_SHORT).show();
        EditTextResult.setText(buffer);

    }


    public void Calender() {
        CalendarDatePickerDialogFragment cdp = new CalendarDatePickerDialogFragment()
                .setOnDateSetListener((CalendarDatePickerDialogFragment.OnDateSetListener) AddnewCatagoActivity.this)
                .setFirstDayOfWeek(Calendar.SUNDAY);
        cdp.show(getSupportFragmentManager(), FRAG_TAG_DATE_PICKER);

    }


    @Override
    public void onDateSet(CalendarDatePickerDialogFragment dialog, int year, int monthOfYear, int dayOfMonth) {
        String month,day;
        if(monthOfYear+1<10)  month = "0"+(monthOfYear+1);
        else month = String.valueOf(monthOfYear+1);
        if(dayOfMonth<10)  day = "0" + dayOfMonth;
        else day = String.valueOf(dayOfMonth);
        date.setText(getString(R.string.calendar_date_picker_result_values, year, month, day)+" 10:10:10");

    }


    private void ShownumberType() {
        LayoutInflater Li = LayoutInflater.from(AddnewCatagoActivity.this);
        View promptsView = Li.inflate(R.layout.number_input, null);
        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(AddnewCatagoActivity.this);
        alertDialogBuilder.setView(promptsView);
        userInput_unit = (EditText) promptsView.findViewById(R.id.unit);
        alertDialogBuilder.setPositiveButton(R.string.ok_myn, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                number.setText(getResources().getString(R.string.unit_myn) + " : " + userInput_unit.getText().toString());

            }

        });
        alertDialogBuilder.setNegativeButton(R.string.cancel_myn, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }

        });
        android.app.AlertDialog dialog = alertDialogBuilder.create();
        dialog.show();

    }


    private void ShowProductType() {
        LayoutInflater Li = LayoutInflater.from(AddnewCatagoActivity.this);
        View promptsView = Li.inflate(R.layout.listview, null);
//        Log.d("Total Size", allequip.size() + "");
//        Log.d("Equipment name", allequip.get(position).size()+ " ");
//        holder.equipment.setText(allequip.get(position).get(0));
//        mProductEntries.add("Add New Category");
//        mProductEntries.add("Nyi Nyi Zaw");
//        mProductEntries.add("Khant Si Thu");
        arrayAdapter = new ArrayAdapter<String>(AddnewCatagoActivity.this, android.R.layout.simple_list_item_1, mProductEntries);

        arrayAdapter.notifyDataSetChanged();

        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(AddnewCatagoActivity.this);
        alertDialogBuilder.setView(promptsView);
        userInput = (EditText) promptsView.findViewById(R.id.inc_product_input);
        final ListView listView = (ListView) promptsView.findViewById(R.id.List);
        // Creating a button - Add New Product
        Button btnNewProduct = new Button(this);
        btnNewProduct.setText("ကုန္ပစၥည္း အသစ္ထည္႔မည္");
        btnNewProduct.setTextColor(getResources().getColor(R.color.white));
        btnNewProduct.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        listView.addFooterView(btnNewProduct);
        listView.setAdapter(arrayAdapter);


        btnNewProduct.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
//
                Intent i = new Intent(AddnewCatagoActivity.this,AddNewProductActivity.class);
//                i.putExtra("State",state);
                i.putExtra("state",state);
                startActivity(i);
            }

        });
        userInput.addTextChangedListener(new TextWatcher() {

            String searchString = userInput.getText().toString().toLowerCase();


            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }


            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                arrayAdapter.getFilter().filter(charSequence);

            }


            @Override
            public void afterTextChanged(Editable editable) {
            }

        });
//        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String select = arrayAdapter.getItem(i);
                categro_id = i;
                userInput.setText(select);
                Toast.makeText(getApplicationContext(),i+"",Toast.LENGTH_LONG).show();

            }

        });
        alertDialogBuilder.setPositiveButton(R.string.ok_myn, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                mProductList.setText(userInput.getText().toString());

            }

        });
        alertDialogBuilder.setNegativeButton(R.string.cancel_myn, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }

        });
        android.app.AlertDialog dialog = alertDialogBuilder.create();
        dialog.show();

    }

    public void insert_income_expense(String id, String upordown) {
        int count = Integer.parseInt(userInput_unit.getText().toString());
        total_price = count * Integer.parseInt(EditTextResult.getText().toString());
        temp_count = String.valueOf(count);
        temp_input = EditTextResult.getText().toString();
        if (upordown.equals("up")) values.put(dataBase.KEY_INCOME_ID, id);
        else values.put(dataBase.KEY_EXPENSE_ID, id);
        values.put(dataBase.KEY_PRODUCT_NAME, userInput.getText().toString());
        values.put(dataBase.KEY_INCOME_EXPENSE_TIMESTAMP, date.getText().toString());
        values.put(dataBase.KEY_PRODUCT_PRICE, total_price + "");
        values.put(dataBase.KEY_DELETED, "0");
        long a = dataBase.save_income_expense(values);
        Log.d("Income Expense", a + "");

    }


    public void insert_expense() {
        Log.d("Category id", categro_id + "");
        values_expense.put(dataBase.KEY_SAVE_DATE, date.getText().toString());
        values_expense.put(dataBase.KEY_CATEGORY_ID, categro_id+"");
        values_expense.put(dataBase.KEY_AMOUNT, total_price + "");
        values_expense.put(dataBase.KEY_UNIT, userInput_unit.getText().toString() + "");
        values_expense.put(dataBase.KEY_PRICE_PER_ONE, EditTextResult.getText().toString() + "");
        values_expense.put(dataBase.KEY_DESCRIPTION, "1");
        values_expense.put(dataBase.KEY_ON_CREDIT, "0");
        values_expense.put(dataBase.KEY_NOTE, "1");
        values_expense.put(dataBase.KEY_EDITED, "0");
        values_expense.put(dataBase.KEY_UPDATED, "0");
        values_expense.put(dataBase.KEY_SEND, "0");
        values_expense.put(dataBase.KEY_UUID, UUID.randomUUID().toString());
        values_expense.put(dataBase.KEY_DELETED, "0");
        values_expense.put(dataBase.KEY_SYNC,0 +"");
//        values_expense.put(dataBase.KEY_EXPENSE_ID,null);
//        values_expense.put(dataBase.KEY_SUBMITTED_AT,date.getText().toString());
        long a = dataBase.insert_expenese(values_expense);
        Log.d("Expense table", a + "");

    }


    public void insert_income() {
        value_income.put(dataBase.KEY_SAVE_DATE, date.getText().toString());
        value_income.put(dataBase.KEY_PRODUCT_TYPE_ID, categro_id+"");
        value_income.put(dataBase.KEY_SALE_AMOUNT, total_price + "");
        value_income.put(dataBase.KEY_UNIT, userInput_unit.getText().toString() + "");
        value_income.put(dataBase.KEY_PRICE_PER_ONE, EditTextResult.getText().toString() + "");
        value_income.put(dataBase.KEY_ON_CREDIT, "0");
        value_income.put(dataBase.KEY_NOTE, "1");
        value_income.put(dataBase.KEY_SEND, "0");
        value_income.put(dataBase.KEY_UUID, UUID.randomUUID().toString());
        value_income.put(dataBase.KEY_EDITED, "0");
        value_income.put(dataBase.KEY_DELETED, "0");
        value_income.put(dataBase.KEY_SYNC, 0);
//        value_income.put(dataBase.KEY_INCOME_ID,);
//        value_income.put(dataBase.KEY_SUBMITTED_AT,);
        long a = dataBase.save_income(value_income);
        Log.d("Income table", a + "");

    }

}

