package com.example.user.onmyanmar.Model;

import java.util.ArrayList;

/**
 * Created by User on 7/27/2017.
 */

public class DataModel_expense {
    ArrayList<NewExpenseSyncModel> data;

    public ArrayList<NewExpenseSyncModel> getData() {
        return data;
    }

    public void setData(ArrayList<NewExpenseSyncModel> data) {
        this.data = data;
    }
}
