package com.example.user.onmyanmar.Model;

import java.util.ArrayList;

/**
 * Created by User on 7/27/2017.
 */

public class Sales_Sync_data {
    ArrayList<Sale_Sync> data;

    public ArrayList<Sale_Sync> getData() {
        return data;
    }

    public void setData(ArrayList<Sale_Sync> data) {
        this.data = data;
    }
}
