package com.example.user.onmyanmar;

import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.rubengees.introduction.Slide;

/**
 * Created by User on 7/3/2017.
 */

public class CustomViewBuilderImpl implements Slide.CustomViewBuilder {

    @NonNull
    @Override
    public View buildView(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
        return inflater.inflate(R.layout.layout_custom, parent, false);
    }
}
