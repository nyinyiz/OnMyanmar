package com.example.user.onmyanmar.adapter;



import android.content.Context;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;

import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;

import android.util.Log;

import android.view.LayoutInflater;

import android.view.View;

import android.view.ViewGroup;

import android.widget.ImageView;

import android.widget.LinearLayout;
import android.widget.TextView;

import android.widget.Toast;


import com.example.user.onmyanmar.AddnewCatagoActivity;
import com.example.user.onmyanmar.AddnewCatagoActivityUpdate;
import com.example.user.onmyanmar.Model.Income_ExpenseModel;

import com.example.user.onmyanmar.Model.Income_Expense_Data_Model;

import com.example.user.onmyanmar.OnMyanmar_DataBase;
import com.example.user.onmyanmar.PrefManager;

import com.example.user.onmyanmar.R;

import com.example.user.onmyanmar.UpDownActivity;
import com.example.user.onmyanmar.api.Application;



import java.util.ArrayList;
import java.util.List;

import me.drakeet.materialdialog.MaterialDialog;


/**

 * Created by User on 6/30/2017.

 */





public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {


    OnMyanmar_DataBase dataBase;

    Context context;TextView image;

    TextView iname,pricevalue,id,upordown,IEid;

    TextView iname2;

    CardView update_income_expense;

    int position;

    View view1;

    PrefManager pref;
    int color=R.color.colorPrimary;
//    LinearLayout ie_color;

    private List<List<String>> allIncome_expense;

   AlertDialog.Builder alertDialog;

    public RecyclerViewAdapter(Context applicationContext, List<List<String>> allIncome) {

        this.context=applicationContext;

        this.allIncome_expense=allIncome;



    }



    @Override

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        view1  = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_single, viewGroup, false);

        return new ViewHolder(view1);

    }





    @Override

    public void onBindViewHolder(final ViewHolder holder, final int position) {

        this.position=position;

        pricevalue.setText(allIncome_expense.get(position).get(5));

        iname.setText(allIncome_expense.get(position).get(3));

        iname2.setText(allIncome_expense.get(position).get(4));//time_stamp

        id.setText(allIncome_expense.get(position).get(0));

        Log.d("position 0 ID",allIncome_expense.get(0).get(0));
//        Log.d("position 1 ID",allIncome_expense.get(1).get(0));

        Log.d("Income",allIncome_expense.get(position).get(2));
        if (allIncome_expense.get(position).get(2).equals("true"))
        {
            upordown.setText("down");
//            ie_color.setBackground(R.color.colorPrimary);
            image.setBackgroundColor(Color.RED);
            pricevalue.setTextColor(Color.RED);
            pricevalue.setText("-"+allIncome_expense.get(position).get(5));
            IEid.setText(allIncome_expense.get(position).get(10));

        }
        else IEid.setText(allIncome_expense.get(position).get(9));

        update_income_expense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (allIncome_expense.get(position).get(2).equals("false"))
//                {
//                    Intent intent=new Intent(context,AddnewCatagoActivityUpdate.class);
//
//                    intent.putExtra("price",allIncome_expense.get(position).get(5));
//                    intent.putExtra("catagoryname",allIncome_expense.get(position).get(3));
//                    intent.putExtra("date",allIncome_expense.get(position).get(4));
//                    intent.putExtra("icon","down");
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_TASK_ON_HOME);
//                    context.startActivity(intent);
//                }
//                else
//                {
//                    Intent intent=new Intent(context,AddnewCatagoActivityUpdate.class);
//
//                    intent.putExtra("price",allIncome_expense.get(position).get(5));
//                    intent.putExtra("catagoryname",allIncome_expense.get(position).get(3));
//                    intent.putExtra("date",allIncome_expense.get(position).get(4));
//                    intent.putExtra("icon","up");
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_TASK_ON_HOME);
//                    context.startActivity(intent);
//                }
            }
        }
        );
        update_income_expense.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
//                Log.d("IEid adapter",IEid.getText().toString());
//
//                final AlertDialog.Builder alertbox = new AlertDialog.Builder(v.getRootView().getContext());
//                alertbox.setMessage("Are you sure u want to delete?");
//                alertbox.setTitle("Warning");
//                alertbox.setIcon(R.drawable.down_icon);
//
//                alertbox.setNeutralButton("OK",
//                        new DialogInterface.OnClickListener() {
//
//                            public void onClick(DialogInterface arg0,
//                                                int arg1) {
//
//                                dataBase.update_income_expense_del(Integer.valueOf(allIncome_expense.get(position).get(0)),upordown.getText().toString(),IEid.getText().toString());
//                                Log.d("Deleted ID",id.getText().toString());
////                                notifyDataSetChanged();
//
//                            }
//                        });
//                alertbox.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                    }
//                });
//                alertbox.show();
//
                return true;
            }

        });








    }



    @Override

    public int getItemCount() {

        return allIncome_expense.size();

    }



    public class ViewHolder extends RecyclerView.ViewHolder {

        //        TextView SubjectTextView;

        public ViewHolder(View view) {



            super(view);

            pref=new PrefManager(context);
            image = (TextView) view.findViewById(R.id.imagetest);

//            ie_color= (LinearLayout) view.findViewById(R.id.ie_color);

            iname = (TextView) view.findViewById(R.id.text1);

            iname2 = (TextView) view.findViewById(R.id.text2);

            pricevalue   = (TextView)view.findViewById(R.id.price);

            update_income_expense= (CardView) view.findViewById(R.id.update_income_expense);

            id=(TextView)view.findViewById(R.id.listID);

            IEid=(TextView)view.findViewById(R.id.IEid);

            upordown=(TextView)view.findViewById(R.id.upordown);

            pref = new PrefManager(context);

            dataBase= new OnMyanmar_DataBase(context,pref.getDB_NAME());

        }

    }

}

