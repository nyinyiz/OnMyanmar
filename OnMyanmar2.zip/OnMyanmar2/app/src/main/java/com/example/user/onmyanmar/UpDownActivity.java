package com.example.user.onmyanmar;


import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;

import android.graphics.Color;

import android.os.Build;

import android.os.Bundle;

import android.support.annotation.RequiresApi;

import android.support.v7.app.ActionBar;

import android.support.v7.app.AppCompatActivity;

import android.support.v7.widget.LinearLayoutManager;

import android.support.v7.widget.RecyclerView;

import android.support.v7.widget.Toolbar;

import android.util.Log;

import android.view.View;

import android.widget.TextView;

import android.widget.Toast;

import com.example.user.onmyanmar.Model.Income_ExpenseModel;

import com.example.user.onmyanmar.Model.Income_Expense_Data_Model;

import com.example.user.onmyanmar.adapter.RecyclerTouchListener;
import com.example.user.onmyanmar.adapter.RecyclerViewAdapter;
import com.example.user.onmyanmar.api.Application;

import com.example.user.onmyanmar.api.RetrofitHelper;

import com.github.clans.fab.FloatingActionMenu;


import java.util.List;

import me.drakeet.materialdialog.MaterialDialog;

import retrofit2.Call;

import retrofit2.Callback;

import retrofit2.Response;

import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_EXPENSE;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_INCOME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_INCOME_EXPENSE_TIMESTAMP;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_PRODUCT_NAME;
import static com.example.user.onmyanmar.OnMyanmar_DataBase.KEY_PRODUCT_PRICE;


@RequiresApi(api = Build.VERSION_CODES.M)
public class UpDownActivity extends AppCompatActivity implements RecyclerView.OnScrollChangeListener {


    OnMyanmar_DataBase dataBase;
    private FloatingActionMenu fam;

    private com.github.clans.fab.FloatingActionButton fabup, fabdown;

    RecyclerView recyclerview;

    RecyclerView.LayoutManager RecyclerViewLayoutManager;

    Toolbar temp;

    List<List<String>> templist;
    List<List<String>> tempincome;


    RetrofitHelper retrofitHelper;


    Income_ExpenseModel allincome_expense;


    MaterialDialog mMaterialDialog;


    Income_Expense_Data_Model data_income_expense;

    PrefManager pref;


    TextView cash_on_hand;

    public int cash_hand;

    public int cash_income;

    public int cash_expense;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_down);
//        if (getIntent().getStringExtra("refresh").equals("refresh"))
//        {
//            loadActivity();
//        }
        loadActivity();

    }

    private void loadActivity() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        cash_on_hand = (TextView) findViewById(R.id.cash_on_hand);
        retrofitHelper = new RetrofitHelper();
        pref = new PrefManager(getApplicationContext());
        dataBase = new OnMyanmar_DataBase(UpDownActivity.this, pref.getDB_NAME());
        allincome_expense = new Income_ExpenseModel();
        /////////////////////////////////////

        cash_on_hand.setText(Application.CASH_ON_HAND + "");

        //////////////////////////////////////////Recycler
        RecyclerView simpleList = (RecyclerView) findViewById(R.id.recyclerview1);
        RecyclerViewLayoutManager = new LinearLayoutManager(getApplicationContext());
        simpleList.setLayoutManager(RecyclerViewLayoutManager);
        templist = dataBase.get_all_income_expense();
        Log.d("UpDown Size", templist.size() + "");
        final RecyclerViewAdapter alertAdapter = new RecyclerViewAdapter(getApplicationContext(), templist);
        simpleList.addOnItemTouchListener(new RecyclerTouchListener(this,
                simpleList, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, final int position) {
                //Values are passing to activity & to fragment as well
//                Toast.makeText(UpDownActivity.this, "Single Click on position        :" + position,
//                        Toast.LENGTH_SHORT).show();
                if (templist.get(position).get(2).equals("true")) {
                    Log.d("value of expense ID", templist.get(position).get(10));
                    tempincome = dataBase.get_expense_by_id(Integer.parseInt(templist.get(position).get(10)));
                    Log.d("price per one", tempincome.get(0).get(1));
                    Log.d("unit", tempincome.get(0).get(0));
                    Intent intent = new Intent(getApplicationContext(), AddnewCatagoActivityUpdate.class);
                    intent.putExtra("id", templist.get(position).get(10));
                    intent.putExtra("price", tempincome.get(0).get(1));
                    intent.putExtra("count", tempincome.get(0).get(0));
                    intent.putExtra("catagoryname", templist.get(position).get(3));
                    intent.putExtra("date", templist.get(position).get(4));
                    intent.putExtra("icon", "down");
                    intent.putExtra("IEID", templist.get(position).get(0));
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_TASK_ON_HOME);
                    startActivity(intent);
                } else {
                    Log.d("value of income id", templist.get(position).get(9));
                    tempincome = dataBase.get_income_by_id(Integer.parseInt(templist.get(position).get(9)));
                    Intent intent = new Intent(getApplicationContext(), AddnewCatagoActivityUpdate.class);
                    intent.putExtra("id", templist.get(position).get(9));
                    intent.putExtra("price", tempincome.get(0).get(1));
                    intent.putExtra("count", tempincome.get(0).get(0));
                    intent.putExtra("catagoryname", templist.get(position).get(3));
                    intent.putExtra("date", templist.get(position).get(4));
                    intent.putExtra("icon", "up");
                    intent.putExtra("IEID", templist.get(position).get(0));
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_TASK_ON_HOME);
                    startActivity(intent);
                }
               finish();
            }

            @Override
            public void onLongClick(View view, final int position) {
                Toast.makeText(UpDownActivity.this, "Long press on position :" + position,
                        Toast.LENGTH_LONG).show();
//                Log.d("IEid adapter",templist.get(position).get(10));
                final AlertDialog.Builder alertbox = new AlertDialog.Builder(view.getRootView().getContext());
                alertbox.setMessage("Are you sure u want to delete?");
                alertbox.setTitle("Warning");
                alertbox.setIcon(R.drawable.down_icon);
                alertbox.setNeutralButton("OK",
                        new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface arg0,
                                                int arg1) {
                                Log.d("expense :", templist.get(position).get(2));
                                if (templist.get(position).get(2).equals("true"))
                                    dataBase.update_income_expense_del(Integer.valueOf(templist.get(position).get(0)), templist.get(position).get(2), templist.get(position).get(10));
                                Log.d("income :", templist.get(position).get(1));
                                if (templist.get(position).get(1).equals("true"))
                                    dataBase.update_income_expense_del(Integer.valueOf(templist.get(position).get(0)), templist.get(position).get(2), templist.get(position).get(9));
                                Log.d("Deleted ID", (templist.get(position).get(0).toString()));
                                Intent intent = new Intent(UpDownActivity.this, UpDownActivity.class);
                                startActivity(intent);
                                finish();

                            }
                        });
                alertbox.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alertbox.show();

            }
        }));
        simpleList.setAdapter(alertAdapter);
        ////////////////////////////////////////////
        // Adding Floating Action Button to bottom right of main view
        fabup = (com.github.clans.fab.FloatingActionButton) findViewById(R.id.fab1);
        fabdown = (com.github.clans.fab.FloatingActionButton) findViewById(R.id.fab2);
//        fam = (FloatingActionMenu) findViewById(R.id.fab_menu);
        fabup.setImageResource(R.drawable.add);
        fabdown.setImageResource(R.drawable.remove);
//       /* fabup.setLabelText(getResources().getString(R.string.income));
//        */fabdown.setLabelText(getResources().getString(R.string.expense));
//        fabup.setVisibility(View.GONE);
//        fabdown.setVisibility(View.GONE);


        //handling each floating action button clicked
        fabup.setOnClickListener(onButtonClick());
        fabdown.setOnClickListener(onButtonClick());

    }

    private View.OnClickListener onButtonClick() {
        return new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (view == fabup) {
                    Intent intent = new Intent(UpDownActivity.this, AddnewCatagoActivity.class);
                    intent.putExtra("catago", "up");
                    startActivity(intent);
                    finish();
//                    Toast.makeText(UpDownActivity.this,"You click Up",Toast.LENGTH_LONG).show();
                } else if (view == fabdown) {
                    Intent intent = new Intent(UpDownActivity.this, AddnewCatagoActivity.class);
                    intent.putExtra("catago", "down");
                    startActivity(intent);
                    finish();
//                    Toast.makeText(UpDownActivity.this,"You click down",Toast.LENGTH_LONG).show();
                }


            }

        };

    }


    @Override
    public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
        final ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.hide();
        int mwidth = getApplicationContext().getResources().getDisplayMetrics().widthPixels;
        int mheight = getApplicationContext().getResources().getDisplayMetrics().heightPixels;
        temp = (Toolbar) findViewById(R.id.toolbar);
        int getwidth = temp.getWidth();
        int getheight = temp.getHeight();
        temp.setMinimumHeight(mheight);
        temp.setMinimumWidth(mwidth);

    }

}

