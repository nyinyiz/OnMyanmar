package com.example.user.onmyanmar.Model;

import java.util.ArrayList;

/**
 * Created by User on 7/10/2017.
 */

public class Income_ExpenseModel {
    ArrayList<Income_Expense_Data_Model> query;

    public ArrayList<Income_Expense_Data_Model> getQuery() {
        return query;
    }

    public void setQuery(ArrayList<Income_Expense_Data_Model> query) {
        this.query = query;
    }
}
