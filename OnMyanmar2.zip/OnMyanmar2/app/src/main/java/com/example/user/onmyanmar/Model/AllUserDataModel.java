package com.example.user.onmyanmar.Model;

import java.util.ArrayList;

/**
 * Created by User on 7/4/2017.
 */

public class AllUserDataModel {

    UserDataModel user_data;
    ArrayList<SaleModel> sales;
    ArrayList<UserMessageDataModel> message;
    ArrayList<AllequipmentsModel> equipments;
    StartupBudgetModel startup_budget;

    public ArrayList<AllequipmentsModel> getEquipments() {
        return equipments;
    }

    public void setEquipments(ArrayList<AllequipmentsModel> equipments) {
        this.equipments = equipments;
    }

    public ArrayList<SaleModel> getSales() {
        return sales;
    }

    public void setSales(ArrayList<SaleModel> sales) {
        this.sales = sales;
    }

    public UserDataModel getUser_data() {
        return user_data;
    }

    public void setUser_data(UserDataModel user_data) {
        this.user_data = user_data;
    }

    public StartupBudgetModel getStartup_budget() {
        return startup_budget;
    }

    public void setStartup_budget(StartupBudgetModel startup_budget) {
        this.startup_budget = startup_budget;
    }

    public ArrayList<UserMessageDataModel> getMessage() {
        return message;
    }

    public void setMessage(ArrayList<UserMessageDataModel> message) {
        this.message = message;
    }



}
